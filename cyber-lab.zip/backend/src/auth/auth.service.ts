import {
  Injectable,
  UnauthorizedException,
  ConflictException,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as argon2 from 'argon2';
import { PrismaService } from '@/database/prisma.service';
import { RegisterDto, LoginDto, ChangePasswordDto, JwtPayload } from './auth.dto';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);
  private readonly loginAttempts = new Map<string, { attempts: number; resetTime: number }>();

  constructor(
    private prisma: PrismaService,
    private jwtService: JwtService,
    private configService: ConfigService,
  ) {}

  async register(dto: RegisterDto) {
    // Check if user already exists
    const existingUser = await this.prisma.user.findFirst({
      where: {
        OR: [{ username: dto.username }, { email: dto.email }],
      },
    });

    if (existingUser) {
      throw new ConflictException('Username or email already exists');
    }

    // Hash password with Argon2id
    const passwordHash = await argon2.hash(dto.password, {
      type: argon2.argon2id,
      memoryCost: 65540,
      timeCost: 3,
      parallelism: 4,
    });

    try {
      const user = await this.prisma.user.create({
        data: {
          username: dto.username,
          email: dto.email,
          displayName: dto.displayName || dto.username,
          passwordHash,
        },
      });

      this.logger.log(`User registered: ${user.username}`);

      return {
        id: user.id,
        username: user.username,
        email: user.email,
        displayName: user.displayName,
      };
    } catch (error) {
      this.logger.error(`Registration failed for ${dto.username}: ${error.message}`);
      throw new BadRequestException('Registration failed');
    }
  }

  async login(dto: LoginDto, ipAddress: string) {
    // Rate limiting
    this.checkLoginAttempts(dto.username, ipAddress);

    const user = await this.prisma.user.findFirst({
      where: {
        OR: [{ username: dto.username }, { email: dto.username }],
      },
    });

    if (!user) {
      this.recordLoginAttempt(dto.username, ipAddress);
      throw new UnauthorizedException('Invalid credentials');
    }

    if (user.isBanned) {
      this.logger.warn(`Banned user attempted login: ${user.username}`);
      throw new UnauthorizedException('Account is banned');
    }

    // Verify password
    const isPasswordValid = await argon2.verify(user.passwordHash, dto.password);

    if (!isPasswordValid) {
      this.recordLoginAttempt(dto.username, ipAddress);
      throw new UnauthorizedException('Invalid credentials');
    }

    // Clear login attempts on successful login
    this.loginAttempts.delete(dto.username);

    // Generate tokens
    const tokens = this.generateTokens(user);

    this.logger.log(`User logged in: ${user.username}`);

    return {
      ...tokens,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        displayName: user.displayName,
        role: user.role,
      },
    };
  }

  async logout(userId: string) {
    // Delete session if exists
    await this.prisma.session.deleteMany({
      where: { userId },
    });

    this.logger.log(`User logged out: ${userId}`);
  }

  async changePassword(userId: string, dto: ChangePasswordDto) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      throw new UnauthorizedException('User not found');
    }

    // Verify current password
    const isPasswordValid = await argon2.verify(user.passwordHash, dto.currentPassword);

    if (!isPasswordValid) {
      throw new UnauthorizedException('Current password is incorrect');
    }

    // Hash new password
    const newPasswordHash = await argon2.hash(dto.newPassword, {
      type: argon2.argon2id,
      memoryCost: 65540,
      timeCost: 3,
      parallelism: 4,
    });

    await this.prisma.user.update({
      where: { id: userId },
      data: { passwordHash: newPasswordHash },
    });

    this.logger.log(`Password changed for user: ${user.username}`);
  }

  private generateTokens(user: any) {
    const payload: JwtPayload = {
      sub: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
    };

    const accessToken = this.jwtService.sign(payload, {
      secret: this.configService.get('JWT_SECRET'),
      expiresIn: this.configService.get('JWT_EXPIRE_IN', '7d'),
    });

    const refreshToken = this.jwtService.sign(payload, {
      secret: this.configService.get('JWT_REFRESH_SECRET'),
      expiresIn: this.configService.get('JWT_REFRESH_EXPIRE_IN', '30d'),
    });

    return { accessToken, refreshToken };
  }

  private checkLoginAttempts(username: string, ipAddress: string) {
    const key = `${username}:${ipAddress}`;
    const attempt = this.loginAttempts.get(key);

    if (attempt && Date.now() < attempt.resetTime) {
      if (attempt.attempts >= 5) {
        throw new UnauthorizedException('Too many login attempts. Try again later.');
      }
    }
  }

  private recordLoginAttempt(username: string, ipAddress: string) {
    const key = `${username}:${ipAddress}`;
    const attempt = this.loginAttempts.get(key);

    if (!attempt) {
      this.loginAttempts.set(key, {
        attempts: 1,
        resetTime: Date.now() + 15 * 60 * 1000, // 15 minutes
      });
    } else {
      attempt.attempts++;
    }
  }
}
