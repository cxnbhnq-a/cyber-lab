import { Module } from '@nestjs/common';
import { DatabaseModule } from '@/database/database.module';
import { ScoreboardService } from './scoreboard.service';
import { ScoreboardController } from './scoreboard.controller';

@Module({
  imports: [DatabaseModule],
  controllers: [ScoreboardController],
  providers: [ScoreboardService],
})
export class ScoreboardModule {}
