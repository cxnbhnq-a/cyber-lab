import { Controller, Get, Query, UseGuards, DefaultValue } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { ScoreboardService } from './scoreboard.service';
import { JwtAuthGuard } from '@/auth/jwt.guard';
import { CurrentUser } from '@/auth/current-user.decorator';

@ApiTags('Scoreboard')
@Controller('scoreboard')
export class ScoreboardController {
  constructor(private scoreboardService: ScoreboardService) {}

  @Get()
  async getScoreboard(
    @Query('limit') limit: number = 100,
    @Query('offset') offset: number = 0,
  ) {
    return this.scoreboardService.getScoreboard(Math.min(limit, 100), offset);
  }

  @Get('me')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getMyScoreboard(@CurrentUser() user: any) {
    return this.scoreboardService.getUserScoreboard(user.id);
  }

  @Get('me/category-stats')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getCategoryStats(@CurrentUser() user: any) {
    return this.scoreboardService.getCategoryStats(user.id);
  }
}
