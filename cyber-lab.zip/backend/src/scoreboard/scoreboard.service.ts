import { Injectable } from '@nestjs/common';
import { PrismaService } from '@/database/prisma.service';

@Injectable()
export class ScoreboardService {
  constructor(private prisma: PrismaService) {}

  async getScoreboard(limit = 100, offset = 0) {
    const solves = await this.prisma.solve.findMany({
      select: {
        user: {
          select: { id: true, username: true, displayName: true, avatar: true },
        },
        solvedAt: true,
        pointsAwarded: true,
      },
      orderBy: { solvedAt: 'asc' },
    });

    // Group by user and calculate scores
    const userScores = new Map<string, any>();

    solves.forEach(solve => {
      const userId = solve.user.id;
      if (!userScores.has(userId)) {
        userScores.set(userId, {
          user: solve.user,
          totalPoints: 0,
          solveCount: 0,
          lastSolvedAt: solve.solvedAt,
          solves: [],
        });
      }

      const userScore = userScores.get(userId);
      userScore.totalPoints += solve.pointsAwarded;
      userScore.solveCount += 1;
      userScore.lastSolvedAt = new Date(
        Math.max(new Date(userScore.lastSolvedAt).getTime(), new Date(solve.solvedAt).getTime()),
      );
      userScore.solves.push({ pointsAwarded: solve.pointsAwarded, solvedAt: solve.solvedAt });
    });

    // Sort by points (desc), then by last solve time (asc - faster is better)
    const ranked = Array.from(userScores.values())
      .sort((a, b) => {
        if (b.totalPoints !== a.totalPoints) {
          return b.totalPoints - a.totalPoints;
        }
        return new Date(a.lastSolvedAt).getTime() - new Date(b.lastSolvedAt).getTime();
      })
      .map((item, index) => ({
        rank: index + 1,
        user: item.user,
        totalPoints: item.totalPoints,
        solveCount: item.solveCount,
        lastSolvedAt: item.lastSolvedAt,
      }));

    return {
      data: ranked.slice(offset, offset + limit),
      total: ranked.length,
    };
  }

  async getUserScoreboard(userId: string) {
    const solves = await this.prisma.solve.findMany({
      where: { userId },
      include: {
        challenge: {
          select: { id: true, title: true, slug: true, difficulty: true },
        },
      },
      orderBy: { solvedAt: 'asc' },
    });

    const totalPoints = solves.reduce((sum, s) => sum + s.pointsAwarded, 0);

    // Get user rank
    const allScoreboard = await this.getScoreboard(999999, 0);
    const userRank = allScoreboard.data.find(item => item.user.id === userId)?.rank || 0;

    return {
      userId,
      totalPoints,
      solveCount: solves.length,
      rank: userRank,
      solves: solves.map(s => ({
        id: s.id,
        challenge: s.challenge,
        pointsAwarded: s.pointsAwarded,
        solvedAt: s.solvedAt,
      })),
    };
  }

  async getCategoryStats(userId: string) {
    const solves = await this.prisma.solve.findMany({
      where: { userId },
      include: {
        challenge: {
          select: {
            categoryId: true,
            difficulty: true,
            solveCount: true,
          },
          include: {
            category: {
              select: { id: true, name: true, color: true },
            },
          },
        },
      },
    });

    const stats = new Map<string, any>();

    solves.forEach(solve => {
      const categoryId = solve.challenge.categoryId;
      if (!stats.has(categoryId)) {
        stats.set(categoryId, {
          category: solve.challenge.challenge.category,
          solveCount: 0,
          points: 0,
          challenges: [],
        });
      }

      const stat = stats.get(categoryId);
      stat.solveCount += 1;
      stat.points += solve.pointsAwarded;
      stat.challenges.push({
        title: solve.challenge.challenge.title,
        difficulty: solve.challenge.difficulty,
        points: solve.pointsAwarded,
      });
    });

    return Array.from(stats.values());
  }
}
