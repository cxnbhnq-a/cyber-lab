import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class AppService {
  constructor(private configService: ConfigService) {}

  getHealth() {
    return {
      status: 'ok',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
    };
  }

  getInfo() {
    return {
      name: this.configService.get('APP_NAME', 'CyberLab Arena'),
      version: '1.0.0',
      environment: this.configService.get('NODE_ENV', 'development'),
    };
  }
}
