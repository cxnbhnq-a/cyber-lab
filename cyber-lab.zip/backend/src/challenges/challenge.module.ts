import { Module } from '@nestjs/common';
import { DatabaseModule } from '@/database/database.module';
import { ChallengeService } from './challenge.service';
import { ChallengeController } from './challenge.controller';

@Module({
  imports: [DatabaseModule],
  controllers: [ChallengeController],
  providers: [ChallengeService],
})
export class ChallengeModule {}
