import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
  Logger,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '@/database/prisma.service';
import { SubmitFlagDto, GetChallengesFilterDto, UnlockHintDto } from './challenge.dto';
import * as argon2 from 'argon2';

@Injectable()
export class ChallengeService {
  private readonly logger = new Logger(ChallengeService.name);

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {}

  async getChallenges(
    userId: string,
    filters: GetChallengesFilterDto,
  ) {
    const skip = (filters.page - 1) * filters.limit;
    const where: any = { isEnabled: true, deletedAt: null };

    if (filters.search) {
      where.OR = [
        { title: { contains: filters.search, mode: 'insensitive' } },
        { description: { contains: filters.search, mode: 'insensitive' } },
        { tags: { hasSome: [filters.search] } },
      ];
    }

    if (filters.category) {
      where.category = { slug: filters.category };
    }

    if (filters.difficulty) {
      where.difficulty = filters.difficulty;
    }

    const orderBy: any = {};
    switch (filters.sort) {
      case 'newest':
        orderBy.createdAt = 'desc';
        break;
      case 'oldest':
        orderBy.createdAt = 'asc';
        break;
      case 'popular':
        orderBy.solveCount = 'desc';
        break;
      case 'difficulty':
        orderBy.difficulty = 'asc';
        break;
      default:
        orderBy.createdAt = 'desc';
    }

    const [challenges, total] = await Promise.all([
      this.prisma.challenge.findMany({
        where,
        skip,
        take: filters.limit,
        orderBy,
        select: {
          id: true,
          title: true,
          slug: true,
          difficulty: true,
          points: true,
          solveCount: true,
          tags: true,
          category: {
            select: { id: true, name: true, icon: true, color: true },
          },
          solves: {
            where: { userId },
            select: { id: true },
          },
        },
      }),
      this.prisma.challenge.count({ where }),
    ]);

    return {
      data: challenges.map(c => ({
        ...c,
        isSolved: c.solves.length > 0,
        solves: undefined,
      })),
      pagination: {
        page: filters.page,
        limit: filters.limit,
        total,
        pages: Math.ceil(total / filters.limit),
      },
    };
  }

  async getChallengeDetail(challengeId: string, userId: string) {
    const challenge = await this.prisma.challenge.findUnique({
      where: { id: challengeId },
      include: {
        category: {
          select: { id: true, name: true, icon: true, color: true },
        },
        author: {
          select: { username: true, displayName: true },
        },
        hints: {
          select: { id: true, title: true, cost: true },
          orderBy: { order: 'asc' },
        },
        attachment: {
          select: { id: true, filename: true, path: true },
        },
        solves: {
          where: { userId },
        },
      },
    });

    if (!challenge || challenge.deletedAt) {
      throw new NotFoundException('Challenge not found');
    }

    // Get unlocked hints for user
    const unlockedHints = await this.prisma.hintUnlock.findMany({
      where: { userId },
      select: { hintId: true },
    });
    const unlockedHintIds = new Set(unlockedHints.map(h => h.hintId));

    return {
      id: challenge.id,
      title: challenge.title,
      slug: challenge.slug,
      description: challenge.description,
      category: challenge.category,
      difficulty: challenge.difficulty,
      points: challenge.points,
      solveCount: challenge.solveCount,
      isSolved: challenge.solves.length > 0,
      tags: challenge.tags,
      serviceUrl: challenge.serviceUrl,
      ncHost: challenge.ncHost,
      ncPort: challenge.ncPort,
      author: challenge.author,
      hints: challenge.hints.map(h => ({
        id: h.id,
        title: h.title,
        cost: h.cost,
        isUnlocked: unlockedHintIds.has(h.id),
      })),
      attachment: challenge.attachment
        ? {
            id: challenge.attachment.id,
            filename: challenge.attachment.filename,
            url: `/uploads/${challenge.attachment.path}`,
          }
        : null,
    };
  }

  async submitFlag(
    challengeId: string,
    userId: string,
    dto: SubmitFlagDto,
    ipAddress: string,
  ) {
    const challenge = await this.prisma.challenge.findUnique({
      where: { id: challengeId },
      include: { flags: true },
    });

    if (!challenge || challenge.deletedAt) {
      throw new NotFoundException('Challenge not found');
    }

    // Rate limiting
    const recentSubmission = await this.prisma.submission.findFirst({
      where: {
        userId,
        challengeId,
        submittedAt: {
          gte: new Date(Date.now() - 60000), // Last minute
        },
      },
    });

    if (recentSubmission) {
      const count = await this.prisma.submission.count({
        where: {
          userId,
          challengeId,
          submittedAt: {
            gte: new Date(Date.now() - 60000),
          },
        },
      });

      if (count >= 10) {
        throw new ForbiddenException('Too many submissions. Try again later.');
      }
    }

    // Check if already solved
    const alreadySolved = await this.prisma.solve.findUnique({
      where: {
        userId_challengeId: {
          userId,
          challengeId,
        },
      },
    });

    if (alreadySolved) {
      throw new ForbiddenException('Challenge already solved');
    }

    // Verify flag
    let isCorrect = false;
    for (const flag of challenge.flags) {
      if (flag.isRegex) {
        const regex = new RegExp(flag.flag);
        if (regex.test(dto.flag)) {
          isCorrect = true;
          break;
        }
      } else {
        // Constant-time comparison
        const match = await argon2.verify(flag.flag, dto.flag);
        if (match) {
          isCorrect = true;
          break;
        }
      }
    }

    // Log submission
    const submission = await this.prisma.submission.create({
      data: {
        userId,
        challengeId,
        submittedFlag: dto.flag, // Don't store actual flag
        isCorrect,
      },
    });

    // Audit log
    await this.prisma.auditLog.create({
      data: {
        userId,
        action: 'SUBMIT_FLAG',
        resourceType: 'Challenge',
        resourceId: challengeId,
        ipAddress,
        changes: JSON.stringify({ isCorrect }),
      },
    });

    if (!isCorrect) {
      this.logger.log(`Failed submission from ${userId} for challenge ${challengeId}`);
      // Don't reveal if it's close or format
      return { isCorrect: false };
    }

    // Flag is correct - create solve
    const points = await this.calculatePoints(challenge);

    await this.prisma.solve.create({
      data: {
        userId,
        challengeId,
        pointsAwarded: points,
      },
    });

    // Update solve count
    await this.prisma.challenge.update({
      where: { id: challengeId },
      data: { solveCount: { increment: 1 } },
    });

    this.logger.log(`User ${userId} solved challenge ${challengeId}`);

    return {
      isCorrect: true,
      points,
      message: 'Flag accepted! 🎉',
    };
  }

  async unlockHint(userId: string, challengeId: string, dto: UnlockHintDto) {
    const hint = await this.prisma.hint.findUnique({
      where: { id: dto.hintId },
    });

    if (!hint || hint.challengeId !== challengeId) {
      throw new NotFoundException('Hint not found');
    }

    // Check if already unlocked
    const unlocked = await this.prisma.hintUnlock.findUnique({
      where: {
        userId_hintId: {
          userId,
          hintId: dto.hintId,
        },
      },
    });

    if (unlocked) {
      throw new BadRequestException('Hint already unlocked');
    }

    // Create unlock
    await this.prisma.hintUnlock.create({
      data: {
        userId,
        hintId: dto.hintId,
      },
    });

    // Apply point cost if any
    if (hint.cost > 0) {
      // Find latest solve for this challenge and deduct points
      const solve = await this.prisma.solve.findFirst({
        where: { userId, challengeId },
        orderBy: { solvedAt: 'desc' },
      });

      if (solve) {
        await this.prisma.solve.update({
          where: { id: solve.id },
          data: { pointsAwarded: { decrement: hint.cost } },
        });
      }
    }

    return { message: 'Hint unlocked' };
  }

  private async calculatePoints(challenge: any): Promise<number> {
    if (!challenge.isDynamic) {
      return challenge.points;
    }

    // Dynamic scoring
    const solves = await this.prisma.solve.count({
      where: { challengeId: challenge.id },
    });

    const solved = Math.max(0, solves);
    const decay = Math.pow(challenge.decayFactor, solved);
    const points = Math.max(
      challenge.minPoints,
      Math.floor(challenge.maxPoints * decay),
    );

    return points;
  }
}
