import {
  Controller,
  Get,
  Post,
  Param,
  Query,
  Body,
  UseGuards,
  Req,
  HttpCode,
  BadRequestException,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { Request } from 'express';
import { ChallengeService } from './challenge.service';
import { JwtAuthGuard } from '@/auth/jwt.guard';
import { CurrentUser } from '@/auth/current-user.decorator';
import {
  SubmitFlagDto,
  GetChallengesFilterDto,
  UnlockHintDto,
} from './challenge.dto';

@ApiTags('Challenges')
@Controller('challenges')
export class ChallengeController {
  constructor(private challengeService: ChallengeService) {}

  @Get()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'search', required: false, type: String })
  @ApiQuery({ name: 'category', required: false, type: String })
  @ApiQuery({ name: 'difficulty', required: false, type: String })
  @ApiQuery({ name: 'sort', required: false, type: String })
  async getChallenges(
    @CurrentUser() user: any,
    @Query() filters: GetChallengesFilterDto,
  ) {
    if (!filters.page) filters.page = 1;
    if (!filters.limit) filters.limit = 20;
    if (filters.limit > 100) filters.limit = 100; // Cap limit

    return this.challengeService.getChallenges(user.id, filters);
  }

  @Get(':challengeId')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  async getChallengeDetail(
    @Param('challengeId') challengeId: string,
    @CurrentUser() user: any,
  ) {
    return this.challengeService.getChallengeDetail(challengeId, user.id);
  }

  @Post(':challengeId/submit')
  @UseGuards(JwtAuthGuard)
  @HttpCode(200)
  @ApiBearerAuth()
  async submitFlag(
    @Param('challengeId') challengeId: string,
    @Body() dto: SubmitFlagDto,
    @CurrentUser() user: any,
    @Req() req: Request,
  ) {
    if (!dto.flag || dto.flag.trim().length === 0) {
      throw new BadRequestException('Flag cannot be empty');
    }

    return this.challengeService.submitFlag(
      challengeId,
      user.id,
      dto,
      req.ip,
    );
  }

  @Post(':challengeId/hints/:hintId/unlock')
  @UseGuards(JwtAuthGuard)
  @HttpCode(200)
  @ApiBearerAuth()
  async unlockHint(
    @Param('challengeId') challengeId: string,
    @Param('hintId') hintId: string,
    @CurrentUser() user: any,
  ) {
    return this.challengeService.unlockHint(user.id, challengeId, { hintId });
  }
}
