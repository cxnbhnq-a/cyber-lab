import { IsString, IsOptional, IsEnum, IsNumber, IsArray } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export enum DifficultyFilter {
  EASY = 'EASY',
  MEDIUM = 'MEDIUM',
  HARD = 'HARD',
  INSANE = 'INSANE',
}

export class GetChallengesFilterDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  @Type(() => Number)
  page?: number = 1;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  @Type(() => Number)
  limit?: number = 20;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  search?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  category?: string;

  @ApiProperty({ required: false, enum: DifficultyFilter })
  @IsOptional()
  @IsEnum(DifficultyFilter)
  difficulty?: DifficultyFilter;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  sort?: 'newest' | 'oldest' | 'popular' | 'difficulty';
}

export class SubmitFlagDto {
  @ApiProperty()
  @IsString()
  flag: string;
}

export class UnlockHintDto {
  @ApiProperty()
  @IsString()
  hintId: string;
}

export class ChallengeResponseDto {
  id: string;
  title: string;
  slug: string;
  description: string;
  category: {
    id: string;
    name: string;
    icon: string;
    color: string;
  };
  difficulty: string;
  points: number;
  solveCount: number;
  isSolved?: boolean;
  tags: string[];
}

export class ChallengeDetailResponseDto extends ChallengeResponseDto {
  serviceUrl?: string;
  ncHost?: string;
  ncPort?: number;
  author: {
    username: string;
    displayName: string;
  };
  hints: Array<{
    id: string;
    title: string;
    cost: number;
    isUnlocked?: boolean;
  }>;
  attachment?: {
    id: string;
    filename: string;
    url: string;
  };
}
