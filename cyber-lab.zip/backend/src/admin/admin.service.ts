import {
  Injectable,
  NotFoundException,
  ConflictException,
  ForbiddenException,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '@/database/prisma.service';
import {
  CreateChallengeDto,
  UpdateChallengeDto,
  UpdateUserDto,
  CreateCategoryDto,
  UpdateSettingsDto,
} from './admin.dto';
import * as argon2 from 'argon2';

@Injectable()
export class AdminService {
  private readonly logger = new Logger(AdminService.name);

  constructor(private prisma: PrismaService) {}

  // Admin Stats
  async getAdminStats(adminId: string) {
    const [totalUsers, totalChallenges, totalSubmissions, recentSolves] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.challenge.count({ where: { deletedAt: null } }),
      this.prisma.submission.count(),
      this.prisma.solve.findMany({
        take: 10,
        orderBy: { solvedAt: 'desc' },
        include: {
          user: { select: { username: true } },
          challenge: { select: { title: true } },
        },
      }),
    ]);

    return {
      totalUsers,
      totalChallenges,
      totalSubmissions,
      recentSolves: recentSolves.map(s => ({
        username: s.user.username,
        challengeTitle: s.challenge.title,
        timestamp: s.solvedAt,
      })),
    };
  }

  // Challenge Management
  async createChallenge(dto: CreateChallengeDto, adminId: string) {
    // Verify category exists
    const category = await this.prisma.category.findUnique({
      where: { id: dto.categoryId },
    });

    if (!category) {
      throw new NotFoundException('Category not found');
    }

    // Check unique slug
    const slug = this.createSlug(dto.title);
    const existing = await this.prisma.challenge.findUnique({
      where: { slug },
    });

    if (existing) {
      throw new ConflictException('Challenge with this slug already exists');
    }

    try {
      const challenge = await this.prisma.challenge.create({
        data: {
          title: dto.title,
          slug,
          description: dto.description,
          categoryId: dto.categoryId,
          difficulty: dto.difficulty,
          points: dto.points,
          isDynamic: dto.isDynamic || false,
          minPoints: dto.minPoints || 50,
          maxPoints: dto.maxPoints || 500,
          serviceUrl: dto.serviceUrl,
          ncHost: dto.ncHost,
          ncPort: dto.ncPort,
          serviceNotes: dto.serviceNotes,
          tags: dto.tags || [],
          authorId: adminId,
          flags: {
            create: dto.flags?.map(f => ({
              flag: f.isRegex ? f.flag : this.hashFlag(f.flag),
              isRegex: f.isRegex || false,
              isCaseSensitive: f.isCaseSensitive || false,
            })) || [],
          },
          hints: {
            create: dto.hints?.map((h, idx) => ({
              title: h.title,
              content: h.content,
              cost: h.cost || 0,
              order: idx,
            })) || [],
          },
        },
      });

      await this.prisma.auditLog.create({
        data: {
          userId: adminId,
          action: 'CREATE_CHALLENGE',
          resourceType: 'Challenge',
          resourceId: challenge.id,
        },
      });

      this.logger.log(`Challenge created: ${challenge.id}`);
      return challenge;
    } catch (error) {
      this.logger.error(`Failed to create challenge: ${error.message}`);
      throw error;
    }
  }

  async updateChallenge(challengeId: string, dto: UpdateChallengeDto, adminId: string) {
    const challenge = await this.prisma.challenge.findUnique({
      where: { id: challengeId },
    });

    if (!challenge) {
      throw new NotFoundException('Challenge not found');
    }

    const updateData: any = {};

    if (dto.title) {
      updateData.title = dto.title;
      updateData.slug = this.createSlug(dto.title);
    }

    if (dto.description !== undefined) updateData.description = dto.description;
    if (dto.difficulty) updateData.difficulty = dto.difficulty;
    if (dto.points) updateData.points = dto.points;
    if (dto.isEnabled !== undefined) updateData.isEnabled = dto.isEnabled;
    if (dto.serviceUrl !== undefined) updateData.serviceUrl = dto.serviceUrl;
    if (dto.ncHost !== undefined) updateData.ncHost = dto.ncHost;
    if (dto.ncPort !== undefined) updateData.ncPort = dto.ncPort;

    const updated = await this.prisma.challenge.update({
      where: { id: challengeId },
      data: updateData,
    });

    await this.prisma.auditLog.create({
      data: {
        userId: adminId,
        action: 'UPDATE_CHALLENGE',
        resourceType: 'Challenge',
        resourceId: challengeId,
        changes: JSON.stringify(dto),
      },
    });

    this.logger.log(`Challenge updated: ${challengeId}`);
    return updated;
  }

  async deleteChallenge(challengeId: string, adminId: string) {
    const challenge = await this.prisma.challenge.findUnique({
      where: { id: challengeId },
    });

    if (!challenge) {
      throw new NotFoundException('Challenge not found');
    }

    // Soft delete
    await this.prisma.challenge.update({
      where: { id: challengeId },
      data: { deletedAt: new Date() },
    });

    await this.prisma.auditLog.create({
      data: {
        userId: adminId,
        action: 'DELETE_CHALLENGE',
        resourceType: 'Challenge',
        resourceId: challengeId,
      },
    });

    this.logger.log(`Challenge soft-deleted: ${challengeId}`);
  }

  async getAllChallenges(page = 1, limit = 20) {
    const skip = (page - 1) * limit;

    const [challenges, total] = await Promise.all([
      this.prisma.challenge.findMany({
        where: { deletedAt: null },
        skip,
        take: limit,
        include: {
          category: { select: { name: true } },
          author: { select: { username: true } },
        },
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.challenge.count({ where: { deletedAt: null } }),
    ]);

    return {
      data: challenges,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  }

  // User Management
  async getAllUsers(page = 1, limit = 20) {
    const skip = (page - 1) * limit;

    const [users, total] = await Promise.all([
      this.prisma.user.findMany({
        skip,
        take: limit,
        select: {
          id: true,
          username: true,
          email: true,
          displayName: true,
          role: true,
          isBanned: true,
          createdAt: true,
        },
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.user.count(),
    ]);

    return {
      data: users,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  }

  async updateUser(userId: string, dto: UpdateUserDto, adminId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const updateData: any = {};

    if (dto.role) updateData.role = dto.role;
    if (dto.isBanned !== undefined) updateData.isBanned = dto.isBanned;

    const updated = await this.prisma.user.update({
      where: { id: userId },
      data: updateData,
    });

    await this.prisma.auditLog.create({
      data: {
        userId: adminId,
        action: 'UPDATE_USER',
        resourceType: 'User',
        resourceId: userId,
        changes: JSON.stringify(dto),
      },
    });

    this.logger.log(`User updated: ${userId}`);
    return updated;
  }

  async banUser(userId: string, adminId: string) {
    return this.updateUser(userId, { isBanned: true }, adminId);
  }

  async unbanUser(userId: string, adminId: string) {
    return this.updateUser(userId, { isBanned: false }, adminId);
  }

  async resetPassword(userId: string, newPassword: string, adminId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const passwordHash = await argon2.hash(newPassword, {
      type: argon2.argon2id,
      memoryCost: 65540,
      timeCost: 3,
      parallelism: 4,
    });

    await this.prisma.user.update({
      where: { id: userId },
      data: { passwordHash },
    });

    await this.prisma.auditLog.create({
      data: {
        userId: adminId,
        action: 'RESET_PASSWORD',
        resourceType: 'User',
        resourceId: userId,
      },
    });

    this.logger.log(`Password reset for user: ${userId}`);
  }

  // Category Management
  async createCategory(dto: CreateCategoryDto, adminId: string) {
    const slug = this.createSlug(dto.name);

    const existing = await this.prisma.category.findUnique({
      where: { slug },
    });

    if (existing) {
      throw new ConflictException('Category with this name already exists');
    }

    const category = await this.prisma.category.create({
      data: {
        name: dto.name,
        slug,
        description: dto.description,
        icon: dto.icon,
        color: dto.color,
      },
    });

    await this.prisma.auditLog.create({
      data: {
        userId: adminId,
        action: 'CREATE_CATEGORY',
        resourceType: 'Category',
        resourceId: category.id,
      },
    });

    this.logger.log(`Category created: ${category.id}`);
    return category;
  }

  async getAllCategories() {
    return this.prisma.category.findMany({
      orderBy: { order: 'asc' },
    });
  }

  async deleteCategory(categoryId: string, adminId: string) {
    const category = await this.prisma.category.findUnique({
      where: { id: categoryId },
    });

    if (!category) {
      throw new NotFoundException('Category not found');
    }

    // Check if category has challenges
    const challengeCount = await this.prisma.challenge.count({
      where: { categoryId },
    });

    if (challengeCount > 0) {
      throw new ForbiddenException('Cannot delete category with challenges');
    }

    await this.prisma.category.delete({
      where: { id: categoryId },
    });

    await this.prisma.auditLog.create({
      data: {
        userId: adminId,
        action: 'DELETE_CATEGORY',
        resourceType: 'Category',
        resourceId: categoryId,
      },
    });

    this.logger.log(`Category deleted: ${categoryId}`);
  }

  // Settings Management
  async getSettings() {
    let settings = await this.prisma.setting.findUnique({
      where: { id: 'config' },
    });

    if (!settings) {
      settings = await this.prisma.setting.create({
        data: { id: 'config' },
      });
    }

    return settings;
  }

  async updateSettings(dto: UpdateSettingsDto, adminId: string) {
    const updateData: any = {};

    if (dto.flagFormat) updateData.flagFormat = dto.flagFormat;
    if (dto.registrationOpen !== undefined) updateData.registrationOpen = dto.registrationOpen;
    if (dto.maintenanceMode !== undefined) updateData.maintenanceMode = dto.maintenanceMode;
    if (dto.scoreboardFrozen !== undefined) updateData.scoreboardFrozen = dto.scoreboardFrozen;
    if (dto.scoreboardPublic !== undefined) updateData.scoreboardPublic = dto.scoreboardPublic;

    let settings = await this.prisma.setting.findUnique({
      where: { id: 'config' },
    });

    if (!settings) {
      settings = await this.prisma.setting.create({
        data: { id: 'config', ...updateData },
      });
    } else {
      settings = await this.prisma.setting.update({
        where: { id: 'config' },
        data: updateData,
      });
    }

    await this.prisma.auditLog.create({
      data: {
        userId: adminId,
        action: 'UPDATE_SETTINGS',
        resourceType: 'Setting',
        changes: JSON.stringify(dto),
      },
    });

    this.logger.log(`Settings updated`);
    return settings;
  }

  // Audit Logs
  async getAuditLogs(page = 1, limit = 50) {
    const skip = (page - 1) * limit;

    const [logs, total] = await Promise.all([
      this.prisma.auditLog.findMany({
        skip,
        take: limit,
        include: {
          user: { select: { username: true } },
        },
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.auditLog.count(),
    ]);

    return {
      data: logs,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  }

  // Submissions
  async getSubmissions(page = 1, limit = 50, challengeId?: string) {
    const skip = (page - 1) * limit;
    const where: any = {};

    if (challengeId) {
      where.challengeId = challengeId;
    }

    const [submissions, total] = await Promise.all([
      this.prisma.submission.findMany({
        where,
        skip,
        take: limit,
        include: {
          user: { select: { username: true } },
          challenge: { select: { title: true } },
        },
        orderBy: { submittedAt: 'desc' },
      }),
      this.prisma.submission.count({ where }),
    ]);

    return {
      data: submissions,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  }

  private createSlug(text: string): string {
    return text
      .toLowerCase()
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim();
  }

  private hashFlag(flag: string): string {
    // This is simplified - in production, use a proper constant-time comparison
    return flag; // Flags should be stored hashed, but for regex we can't hash
  }
}
