import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  Query,
  UseGuards,
  HttpCode,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { AdminService } from './admin.service';
import { JwtAuthGuard } from '@/auth/jwt.guard';
import { RoleGuard } from '@/auth/role.guard';
import { Roles } from '@/auth/roles.decorator';
import { CurrentUser } from '@/auth/current-user.decorator';
import {
  CreateChallengeDto,
  UpdateChallengeDto,
  UpdateUserDto,
  CreateCategoryDto,
  UpdateSettingsDto,
} from './admin.dto';

@ApiTags('Admin')
@Controller('admin')
@UseGuards(JwtAuthGuard, RoleGuard)
@Roles('ADMIN', 'SUPERADMIN')
@ApiBearerAuth()
export class AdminController {
  constructor(private adminService: AdminService) {}

  // Dashboard
  @Get('stats')
  async getStats(@CurrentUser() user: any) {
    return this.adminService.getAdminStats(user.id);
  }

  // Challenges
  @Get('challenges')
  async getAllChallenges(
    @Query('page') page: number = 1,
    @Query('limit') limit: number = 20,
  ) {
    return this.adminService.getAllChallenges(page, Math.min(limit, 100));
  }

  @Post('challenges')
  @HttpCode(201)
  async createChallenge(
    @Body() dto: CreateChallengeDto,
    @CurrentUser() user: any,
  ) {
    return this.adminService.createChallenge(dto, user.id);
  }

  @Put('challenges/:challengeId')
  async updateChallenge(
    @Param('challengeId') challengeId: string,
    @Body() dto: UpdateChallengeDto,
    @CurrentUser() user: any,
  ) {
    return this.adminService.updateChallenge(challengeId, dto, user.id);
  }

  @Delete('challenges/:challengeId')
  @HttpCode(204)
  async deleteChallenge(
    @Param('challengeId') challengeId: string,
    @CurrentUser() user: any,
  ) {
    await this.adminService.deleteChallenge(challengeId, user.id);
  }

  // Users
  @Get('users')
  async getAllUsers(
    @Query('page') page: number = 1,
    @Query('limit') limit: number = 20,
  ) {
    return this.adminService.getAllUsers(page, Math.min(limit, 100));
  }

  @Put('users/:userId')
  async updateUser(
    @Param('userId') userId: string,
    @Body() dto: UpdateUserDto,
    @CurrentUser() user: any,
  ) {
    return this.adminService.updateUser(userId, dto, user.id);
  }

  @Post('users/:userId/ban')
  @HttpCode(200)
  async banUser(
    @Param('userId') userId: string,
    @CurrentUser() user: any,
  ) {
    return this.adminService.banUser(userId, user.id);
  }

  @Post('users/:userId/unban')
  @HttpCode(200)
  async unbanUser(
    @Param('userId') userId: string,
    @CurrentUser() user: any,
  ) {
    return this.adminService.unbanUser(userId, user.id);
  }

  @Post('users/:userId/reset-password')
  @HttpCode(200)
  async resetPassword(
    @Param('userId') userId: string,
    @Body() body: { password: string },
    @CurrentUser() user: any,
  ) {
    await this.adminService.resetPassword(userId, body.password, user.id);
    return { message: 'Password reset successfully' };
  }

  // Categories
  @Get('categories')
  async getAllCategories() {
    return this.adminService.getAllCategories();
  }

  @Post('categories')
  @HttpCode(201)
  async createCategory(
    @Body() dto: CreateCategoryDto,
    @CurrentUser() user: any,
  ) {
    return this.adminService.createCategory(dto, user.id);
  }

  @Delete('categories/:categoryId')
  @HttpCode(204)
  async deleteCategory(
    @Param('categoryId') categoryId: string,
    @CurrentUser() user: any,
  ) {
    await this.adminService.deleteCategory(categoryId, user.id);
  }

  // Settings
  @Get('settings')
  async getSettings() {
    return this.adminService.getSettings();
  }

  @Put('settings')
  async updateSettings(
    @Body() dto: UpdateSettingsDto,
    @CurrentUser() user: any,
  ) {
    return this.adminService.updateSettings(dto, user.id);
  }

  // Audit Logs
  @Get('audit-logs')
  async getAuditLogs(
    @Query('page') page: number = 1,
    @Query('limit') limit: number = 50,
  ) {
    return this.adminService.getAuditLogs(page, Math.min(limit, 100));
  }

  // Submissions
  @Get('submissions')
  async getSubmissions(
    @Query('page') page: number = 1,
    @Query('limit') limit: number = 50,
    @Query('challengeId') challengeId?: string,
  ) {
    return this.adminService.getSubmissions(page, Math.min(limit, 100), challengeId);
  }
}
