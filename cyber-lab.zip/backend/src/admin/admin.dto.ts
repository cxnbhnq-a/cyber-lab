import {
  IsString,
  IsOptional,
  IsBoolean,
  IsNumber,
  IsArray,
  IsEnum,
  IsUrl,
  MaxLength,
  MinLength,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export enum UserRoleEnum {
  USER = 'USER',
  MODERATOR = 'MODERATOR',
  ADMIN = 'ADMIN',
  SUPERADMIN = 'SUPERADMIN',
}

// Challenge DTOs
export class CreateChallengeDto {
  @ApiProperty()
  @IsString()
  @MinLength(3)
  title: string;

  @ApiProperty()
  @IsString()
  description: string;

  @ApiProperty()
  @IsString()
  categoryId: string;

  @ApiProperty()
  @IsEnum(['EASY', 'MEDIUM', 'HARD', 'INSANE'])
  difficulty: string;

  @ApiProperty()
  @IsNumber()
  points: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  serviceUrl?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  ncHost?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  ncPort?: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  serviceNotes?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  isDynamic?: boolean;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  minPoints?: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  maxPoints?: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];

  @ApiProperty({ required: false })
  @IsOptional()
  @IsArray()
  flags?: Array<{ flag: string; isRegex?: boolean; isCaseSensitive?: boolean }>;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsArray()
  hints?: Array<{ title: string; content: string; cost?: number }>;
}

export class UpdateChallengeDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  title?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  categoryId?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsEnum(['EASY', 'MEDIUM', 'HARD', 'INSANE'])
  difficulty?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  points?: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  isEnabled?: boolean;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  serviceUrl?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  ncHost?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  ncPort?: number;
}

// User DTOs
export class UpdateUserDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsEnum(UserRoleEnum)
  role?: UserRoleEnum;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  isBanned?: boolean;
}

export class AdminStatsDto {
  totalUsers: number;
  totalChallenges: number;
  totalSubmissions: number;
  failedLoginAttempts: number;
  recentSolves: Array<{
    username: string;
    challengeTitle: string;
    timestamp: Date;
  }>;
}

export class CreateCategoryDto {
  @ApiProperty()
  @IsString()
  @MinLength(2)
  name: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  icon?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  color?: string;
}

export class UpdateSettingsDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  flagFormat?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  registrationOpen?: boolean;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  maintenanceMode?: boolean;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  scoreboardFrozen?: boolean;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  scoreboardPublic?: boolean;
}
