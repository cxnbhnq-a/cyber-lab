import { PrismaClient, UserRole } from '@prisma/client';
import * as argon2 from 'argon2';

const prisma = new PrismaClient();

async function main() {
  // Create admin user
  const adminPassword = await argon2.hash('Admin@123456', {
    type: argon2.argon2id,
    memoryCost: 65540,
    timeCost: 3,
    parallelism: 4,
  });

  const adminUser = await prisma.user.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      username: 'admin',
      email: 'admin@cyberlab.local',
      displayName: 'Administrator',
      passwordHash: adminPassword,
      role: UserRole.SUPERADMIN,
      isEmailVerified: true,
    },
  });

  console.log('✅ Admin user created:', adminUser.username);

  // Create categories
  const categories = [
    { name: 'Web', icon: '🌐', color: '#00d4ff' },
    { name: 'Pwn', icon: '💣', color: '#ff006e' },
    { name: 'Crypto', icon: '🔐', color: '#8338ec' },
    { name: 'Forensics', icon: '🔍', color: '#fb5607' },
    { name: 'Reverse', icon: '⚙️', color: '#ffbe0b' },
    { name: 'Misc', icon: '🎯', color: '#00ff00' },
    { name: 'OSINT', icon: '🕵️', color: '#00bbf9' },
  ];

  const createdCategories = await Promise.all(
    categories.map((cat, idx) =>
      prisma.category.upsert({
        where: { slug: cat.name.toLowerCase() },
        update: {},
        create: {
          name: cat.name,
          slug: cat.name.toLowerCase(),
          icon: cat.icon,
          color: cat.color,
          order: idx,
        },
      }),
    ),
  );

  console.log('✅ Categories created:', createdCategories.length);

  // Create dummy challenges
  const webCategory = createdCategories[0];

  const challenge1 = await prisma.challenge.upsert({
    where: { slug: 'simple-login-bypass' },
    update: {},
    create: {
      title: 'Simple Login Bypass',
      slug: 'simple-login-bypass',
      description:
        '# Simple Login Bypass\n\nA basic web challenge where you need to bypass a simple login form.\n\n**Hint**: Try common SQL injection techniques.\n\n**Flag format**: CXN{...}',
      categoryId: webCategory.id,
      difficulty: 'EASY',
      points: 100,
      solveCount: 0,
      authorId: adminUser.id,
      tags: ['sql-injection', 'web'],
      serviceUrl: 'http://localhost:8001',
      flags: {
        create: [
          {
            flag: 'CXN{sql_inject10n_is_fun}',
            isRegex: false,
            isCaseSensitive: false,
          },
        ],
      },
      hints: {
        create: [
          {
            title: 'First Hint',
            content: '```\nTry using single quote in username field\n```',
            cost: 10,
            order: 0,
          },
          {
            title: 'Second Hint',
            content: '```\nCommon SQL injection: admin\\' --\n```',
            cost: 20,
            order: 1,
          },
        ],
      },
    },
  });

  console.log('✅ Challenge created:', challenge1.slug);

  // Create default settings
  await prisma.setting.upsert({
    where: { id: 'config' },
    update: {},
    create: {
      id: 'config',
      flagFormat: 'CXN{.*}',
      registrationOpen: true,
      maintenanceMode: false,
      scoreboardFrozen: false,
      scoreboardPublic: true,
      themeDark: true,
      primaryColor: '#8b5cf6',
    },
  });

  console.log('✅ Settings initialized');

  console.log('\n🎉 Database seeding completed!');
  console.log('Admin credentials:');
  console.log('  Username: admin');
  console.log('  Password: Admin@123456');
}

main()
  .catch(e => {
    console.error('❌ Seeding error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
