# CyberLab Arena - Docker Challenges Guide

Panduan menjalankan challenges di Docker secara terpisah dari platform utama.

⚠️ **PENTING**: Platform utama CyberLab Arena **TIDAK MENGGUNAKAN DOCKER**. Docker hanya untuk challenges terpisah.

## 📋 Overview

- **Platform Utama**: Ubuntu Server native (Nginx, systemd, PostgreSQL, Redis)
- **Challenges**: Docker containers di `/opt/ctf-challenges/`
- **Challenge Admin**: Manual management di dashboard
- **Challenge Service Info**: Disimpan di database (URL, port, attachment, dll)

## 🚀 Quick Start

### 1. Setup Docker

```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo apt install -y docker-compose

# Add user to docker group
sudo usermod -aG docker cyberlab

# Verify
docker --version
docker-compose --version
```

### 2. Create Challenge Directory Structure

```bash
# Create challenges directory
sudo mkdir -p /opt/ctf-challenges
sudo chown -R cyberlab:cyberlab /opt/ctf-challenges

# Create subdirectories per category
mkdir -p /opt/ctf-challenges/{web,pwn,crypto,forensics,reverse,misc}

# Example structure
/opt/ctf-challenges/
├── web/
│   ├── simple_login/
│   │   ├── Dockerfile
│   │   ├── docker-compose.yml
│   │   ├── app/
│   │   └── README.md
│   └── advanced_php/
│       └── ...
├── pwn/
│   └── buffer_overflow/
│       ├── Dockerfile
│       ├── binary
│       └── ...
└── README.md
```

### 3. Example Web Challenge

**File: `/opt/ctf-challenges/web/simple_login/Dockerfile`**

```dockerfile
FROM python:3.11-slim

WORKDIR /app

RUN pip install flask

COPY app/ /app/

EXPOSE 8080

CMD ["python", "app.py"]
```

**File: `/opt/ctf-challenges/web/simple_login/app/app.py`**

```python
from flask import Flask, request, render_template
import os

app = Flask(__name__)

# Hard-code simple flag
SECRET_FLAG = os.getenv('FLAG', 'CXN{vulnerable_to_sql_injection}')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username', '')
    password = request.form.get('password', '')
    
    # Intentionally vulnerable to SQL injection
    # This is for educational purposes
    if username == 'admin' and password == 'admin123':
        return f'<h1>Welcome! Your flag: {SECRET_FLAG}</h1>'
    
    return '<h1>Login Failed</h1>', 401

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
```

**File: `/opt/ctf-challenges/web/simple_login/docker-compose.yml`**

```yaml
version: '3.8'

services:
  web-challenge:
    build: .
    container_name: ctf_web_simple_login
    ports:
      - "8001:8080"
    environment:
      - FLAG=CXN{vulnerable_to_sql_injection}
    restart: unless-stopped
    networks:
      - ctf-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/"]
      interval: 30s
      timeout: 10s
      retries: 3

networks:
  ctf-network:
    driver: bridge
```

### 4. Running Challenges

```bash
# Navigate to challenge directory
cd /opt/ctf-challenges/web/simple_login

# Build and start container
docker-compose up -d

# View logs
docker-compose logs -f

# Stop challenge
docker-compose down

# Restart challenge
docker-compose restart
```

### 5. Register Challenge di Platform

Login ke admin panel (`https://cyberlab.example.com/admin`):

1. **Create Category**: Web, Pwn, Crypto, etc.
2. **Create Challenge**:
   - Title: "Simple Login Bypass"
   - Description: Challenge details
   - Category: Web
   - Difficulty: Easy
   - Points: 100
   - **Service URL**: `http://your-server-ip:8001` atau `https://cyberlab.example.com:8001`
   - Upload attachment (jika ada)
   - Add flags (solution)
   - Add hints

3. **Users dapat akses challenge** via platform atau direct URL

## 🐳 Docker Challenge Examples

### Example 1: Pwn Challenge (Binary with Netcat)

**File: `/opt/ctf-challenges/pwn/buffer_overflow/Dockerfile`**

```dockerfile
FROM ubuntu:22.04

RUN apt-get update && apt-get install -y \
    gcc \
    netcat-openbsd \
    xinetd

WORKDIR /pwn

COPY binary /pwn/
RUN chmod +x /pwn/binary

# Setup xinetd untuk netcat service
COPY xinetd_config /etc/xinetd.d/pwn

EXPOSE 9001

CMD ["/etc/init.d/xinetd", "start", "-D"]
```

**File: `/opt/ctf-challenges/pwn/buffer_overflow/xinetd_config`**

```
service pwn
{
    type = UNLISTED
    port = 9001
    socket_type = stream
    protocol = tcp
    wait = no
    user = nobody
    server = /pwn/binary
    server_args = {}
}
```

**File: `/opt/ctf-challenges/pwn/buffer_overflow/docker-compose.yml`**

```yaml
version: '3.8'

services:
  pwn-challenge:
    build: .
    container_name: ctf_pwn_buffer_overflow
    ports:
      - "9001:9001"
    restart: unless-stopped
    networks:
      - ctf-network
    security_opt:
      - "seccomp=unconfined"  # Untuk debugging tools

networks:
  ctf-network:
    driver: bridge
```

**Admin Registration**:
- Service URL: (leave empty)
- NC Host: `your-server-ip`
- NC Port: `9001`

```bash
# User akan connect dengan: nc your-server-ip 9001
```

### Example 2: Crypto Challenge

**File: `/opt/ctf-challenges/crypto/aes_decryption/Dockerfile`**

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY app.py /app/
COPY requirements.txt /app/

RUN pip install -r requirements.txt

CMD ["python", "app.py"]
```

**File: `/opt/ctf-challenges/crypto/aes_decryption/requirements.txt`**

```
pycryptodome==3.18.0
```

**File: `/opt/ctf-challenges/crypto/aes_decryption/app.py`**

```python
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import binascii

# Challenge setup
key = b'0123456789abcdef'  # 16 bytes
iv = b'fedcba9876543210'   # 16 bytes
plaintext = b'CXN{crypto_is_fun}'

# Encrypt
cipher = AES.new(key, AES.MODE_CBC, iv)
ciphertext = cipher.encrypt(plaintext.ljust(16))

print("=== AES Decryption Challenge ===")
print(f"Ciphertext: {binascii.hexlify(ciphertext).decode()}")
print(f"IV: {binascii.hexlify(iv).decode()}")
print("Decrypt the ciphertext to get the flag!")
print("Hint: Key is 16 ASCII characters")

# Solution:
# key = "0123456789abcdef"
# iv = bytes.fromhex("fedcba9876543210")
# ciphertext = bytes.fromhex("...")
# cipher = AES.new(key.encode(), AES.MODE_CBC, iv)
# plaintext = cipher.decrypt(ciphertext).strip()
```

## 🛠️ Management Commands

```bash
# Start all challenges
docker-compose -f /opt/ctf-challenges/*/docker-compose.yml up -d

# Stop all challenges
docker-compose -f /opt/ctf-challenges/*/docker-compose.yml down

# View running containers
docker ps

# View container logs
docker logs <container_id>

# SSH into container (untuk debugging)
docker exec -it <container_id> /bin/bash

# Remove container dan rebuild
docker-compose down
docker-compose rm
docker-compose up -d --build

# Check container health
docker ps --format "table {{.Names}}\t{{.Status}}"
```

## 📊 Challenge Status Dashboard

**Script: `/opt/ctf-challenges/status.sh`**

```bash
#!/bin/bash

echo "=== CyberLab Arena - Challenge Status ==="
echo ""

for dir in /opt/ctf-challenges/*/; do
    category=$(basename "$dir")
    echo "Category: $category"
    
    cd "$dir"
    
    if [ -f docker-compose.yml ]; then
        docker-compose ps
    fi
    
    echo ""
done

echo "Total running containers:"
docker ps --filter "label=com.docker.compose.project" -q | wc -l
```

## 🔐 Security Considerations

1. **Network Isolation**: Challenges harus terpisah network dari platform
2. **Resource Limits**: Set CPU dan memory limits di docker-compose
3. **No Root**: Jangan run container sebagai root
4. **Read-Only FS**: Gunakan read-only filesystem jika memungkinkan
5. **No Docker Socket**: Backend platform JANGAN punya akses ke `/var/run/docker.sock`

**Example secure docker-compose:**

```yaml
version: '3.8'

services:
  challenge:
    build: .
    container_name: ctf_challenge
    ports:
      - "8001:8080"
    
    # Resource limits
    deploy:
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
        reservations:
          cpus: '0.25'
          memory: 256M
    
    # Security settings
    security_opt:
      - no-new-privileges:true
    user: "1000:1000"  # Non-root user
    read_only: true
    tmpfs: /tmp
    
    networks:
      - ctf-network

networks:
  ctf-network:
    driver: bridge
```

## 📝 Challenge Template

**Reusable template untuk membuat challenge baru:**

```bash
mkdir -p /opt/ctf-challenges/category/challenge_name/app

# Create files
cat > /opt/ctf-challenges/category/challenge_name/Dockerfile << 'EOF'
FROM ubuntu:22.04
WORKDIR /app
COPY app/ /app/
EXPOSE 8080
CMD ["bash", "start.sh"]
EOF

cat > /opt/ctf-challenges/category/challenge_name/docker-compose.yml << 'EOF'
version: '3.8'
services:
  challenge:
    build: .
    container_name: ctf_category_challenge_name
    ports:
      - "8XXX:8080"
    environment:
      - FLAG=CXN{put_flag_here}
    restart: unless-stopped
networks:
  ctf-network:
    driver: bridge
EOF

cat > /opt/ctf-challenges/category/challenge_name/README.md << 'EOF'
# Challenge Name

## Description
Challenge description here

## Running
```bash
docker-compose up -d
```

## Solution
Solution walkthrough here
EOF
```

## 🚀 Advanced Features (Future)

CyberLab Arena dapat dikembangkan dengan:

1. **Auto Challenge Deployment**: Admin dapat upload Dockerfile dan auto-deploy
2. **Challenge Container Manager**: Backend mengontrol container lifecycle
3. **Docker Registry Integration**: Private registry untuk challenge images
4. **Challenge Sandboxing**: Isolate challenges dengan security policies
5. **Monitor Resource Usage**: Track CPU, memory, network per challenge
6. **Challenge Logs**: Centralized logging dari semua containers
7. **Challenge Snapshot**: Save state untuk reset functionality
8. **Challenge Scaling**: Multiple instances per challenge

## 📞 Troubleshooting

### Container not starting

```bash
# Check logs
docker-compose logs -f

# Check Dockerfile syntax
docker build --no-cache .

# Check port conflicts
netstat -tuln | grep 8001
```

### Port conflicts

```bash
# Find what's using the port
lsof -i :8001

# Kill process atau use different port
```

### Performance issues

```bash
# Check resource usage
docker stats

# Increase limits di docker-compose.yml
deploy:
  resources:
    limits:
      cpus: '1.0'
      memory: 1G
```

## 📚 Resources

- [Docker Documentation](https://docs.docker.com/)
- [Docker Compose Reference](https://docs.docker.com/compose/compose-file/)
- [Docker Security Best Practices](https://docs.docker.com/engine/security/)
- [CTF Challenge Best Practices](https://ctf101.org/)

---

**Happy Challenge Building!** 🚀
