# CyberLab Arena - Ubuntu Server Deployment Guide

Panduan lengkap untuk deployment CyberLab Arena di Ubuntu Server 22.04 LTS secara **native (tanpa Docker)**.

## 📋 Prerequisites

### System Requirements
- **OS**: Ubuntu Server 22.04 LTS
- **CPU**: 2+ cores
- **RAM**: 4GB minimal (8GB recommended)
- **Disk**: 20GB+ free space
- **Network**: Fixed IP, domain name registered

### Required Software (akan diinstall)
- Node.js 18+ dengan npm
- PostgreSQL 14+
- Redis 7+
- Nginx
- Git
- Certbot (SSL)
- UFW (Firewall)

## 🚀 Step-by-Step Installation

### 1. Update System dan Install Dependencies

```bash
# Update system
sudo apt update
sudo apt upgrade -y

# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verify
node --version  # v18.x.x
npm --version   # 9.x.x
```

### 2. Install PostgreSQL

```bash
# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Start and enable service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and user
sudo -u postgres psql << EOF
CREATE USER cyberlab_user WITH PASSWORD 'StrongPassword123!';
CREATE DATABASE cyberlab_db OWNER cyberlab_user;
GRANT ALL PRIVILEGES ON DATABASE cyberlab_db TO cyberlab_user;
ALTER SYSTEM SET listen_addresses = 'localhost';
EOF

# Reload PostgreSQL config
sudo systemctl restart postgresql

# Verify connection
psql -U cyberlab_user -d cyberlab_db -h localhost -c "\dt"
```

### 3. Install Redis

```bash
# Install Redis
sudo apt install -y redis-server

# Configure Redis to listen only on localhost
sudo sed -i 's/^# bind 127.0.0.1/bind 127.0.0.1/' /etc/redis/redis.conf

# Start and enable
sudo systemctl start redis-server
sudo systemctl enable redis-server

# Verify
redis-cli ping  # Should return: PONG
```

### 4. Install Nginx

```bash
# Install Nginx
sudo apt install -y nginx

# Enable and start
sudo systemctl start nginx
sudo systemctl enable nginx
```

### 5. Create Application User and Directories

```bash
# Create cyberlab user
sudo useradd -m -s /bin/bash cyberlab
sudo usermod -aG sudo cyberlab

# Create application directory
sudo mkdir -p /var/www/cyberlab
sudo mkdir -p /var/www/cyberlab/uploads
sudo mkdir -p /var/www/cyberlab/logs
sudo mkdir -p /var/backups/cyberlab

# Set permissions
sudo chown -R cyberlab:cyberlab /var/www/cyberlab
sudo chown -R cyberlab:cyberlab /var/backups/cyberlab
sudo chmod -R 755 /var/www/cyberlab
sudo chmod -R 700 /var/www/cyberlab/uploads
sudo chmod -R 755 /var/www/cyberlab/logs

# Create logrotate config
sudo tee /etc/logrotate.d/cyberlab > /dev/null << EOF
/var/www/cyberlab/logs/*.log {
    daily
    rotate 14
    missingok
    compress
    delaycompress
    notifempty
    create 644 cyberlab cyberlab
    postrotate
        systemctl reload cyberlab-backend > /dev/null 2>&1 || true
        systemctl reload cyberlab-frontend > /dev/null 2>&1 || true
    endscript
}
EOF
```

### 6. Clone dan Setup Application

```bash
# Switch to cyberlab user
sudo su - cyberlab

# Clone repository
git clone <repository-url> /var/www/cyberlab
cd /var/www/cyberlab

# Or copy files manually if not using git
# scp -r ./cyberlab-arena/* cyberlab@server:/var/www/cyberlab/
```

### 7. Setup Backend (NestJS)

```bash
# Navigate to backend
cd /var/www/cyberlab/backend

# Install dependencies
npm install --production

# Create .env file
cat > .env << 'EOF'
NODE_ENV=production
APP_NAME=CyberLab Arena
APP_URL=https://cyberlab.example.com
API_URL=https://cyberlab.example.com/api
FRONTEND_URL=https://cyberlab.example.com

BACKEND_PORT=3001
BACKEND_HOST=localhost

DATABASE_URL="postgresql://cyberlab_user:StrongPassword123!@localhost:5432/cyberlab_db"
DATABASE_POOL_MIN=2
DATABASE_POOL_MAX=20

REDIS_URL="redis://localhost:6379/0"

JWT_SECRET=$(openssl rand -base64 32)
JWT_EXPIRE_IN=7d
JWT_REFRESH_SECRET=$(openssl rand -base64 32)
JWT_REFRESH_EXPIRE_IN=30d

SESSION_SECRET=$(openssl rand -base64 32)
SESSION_EXPIRE_IN=86400000

RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOGIN_RATE_LIMIT_WINDOW_MS=900000
LOGIN_RATE_LIMIT_MAX_REQUESTS=5

UPLOAD_DIR=/var/www/cyberlab/uploads
MAX_FILE_SIZE=104857600
ALLOWED_FILE_TYPES=zip,rar,txt,pdf,jar,elf,so

LOG_DIR=/var/www/cyberlab/logs
LOG_LEVEL=info

CORS_ORIGIN=https://cyberlab.example.com
CORS_CREDENTIALS=true

ADMIN_EMAIL=admin@cyberlab.example.com
ADMIN_PASSWORD=$(openssl rand -base64 16)

ENABLE_TEAM_MODE=true
ENABLE_DYNAMIC_SCORING=true
ENABLE_HINT_COST=true
ENABLE_MFA_FOR_ADMIN=false
EOF

# Build backend
npm run build

# Run migrations
npm run prisma:migrate:deploy

# Seed database (admin user akan tercreate)
npm run prisma:seed

# Note admin password dari output seed

# Exit cyberlab user
exit
```

### 8. Setup Frontend (Next.js)

```bash
# Switch to cyberlab user
sudo su - cyberlab

# Navigate to frontend
cd /var/www/cyberlab/frontend

# Install dependencies
npm install --production

# Create .env.production.local
cat > .env.production.local << 'EOF'
NEXT_PUBLIC_API_URL=https://cyberlab.example.com/api
EOF

# Build frontend
npm run build

# Exit cyberlab user
exit
```

### 9. Setup systemd Services

```bash
# Copy service files
sudo cp /var/www/cyberlab/systemd/cyberlab-backend.service /etc/systemd/system/
sudo cp /var/www/cyberlab/systemd/cyberlab-frontend.service /etc/systemd/system/

# Update paths in service files if needed
# Edit /etc/systemd/system/cyberlab-backend.service
# Edit /etc/systemd/system/cyberlab-frontend.service

# Reload systemd
sudo systemctl daemon-reload

# Enable services to start on boot
sudo systemctl enable cyberlab-backend
sudo systemctl enable cyberlab-frontend

# Start services
sudo systemctl start cyberlab-backend
sudo systemctl start cyberlab-frontend

# Check status
sudo systemctl status cyberlab-backend
sudo systemctl status cyberlab-frontend

# View logs
sudo journalctl -u cyberlab-backend -n 50 -f
sudo journalctl -u cyberlab-frontend -n 50 -f
```

### 10. Setup Nginx Reverse Proxy

```bash
# Copy Nginx config
sudo cp /var/www/cyberlab/nginx/cyberlab.conf /etc/nginx/sites-available/

# Update server_name in config
sudo sed -i 's/cyberlab.example.com/your-domain.com/g' /etc/nginx/sites-available/cyberlab.conf

# Create symbolic link to enable site
sudo ln -s /etc/nginx/sites-available/cyberlab.conf /etc/nginx/sites-enabled/

# Remove default site
sudo rm /etc/nginx/sites-enabled/default

# Test Nginx config
sudo nginx -t

# Reload Nginx (HTTP only for now)
sudo systemctl reload nginx
```

### 11. Setup SSL Certificate dengan Certbot

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Get SSL certificate
sudo certbot certonly --nginx \
  -d cyberlab.example.com \
  -d www.cyberlab.example.com \
  --agree-tos \
  --register-unsafely-without-email

# Update Nginx config with SSL paths
# Edit /etc/nginx/sites-available/cyberlab.conf
# Uncomment SSL sections dan update certificate paths

# Reload Nginx
sudo systemctl reload nginx

# Setup auto-renewal
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer

# Test renewal
sudo certbot renew --dry-run
```

### 12. Setup Firewall (UFW)

```bash
# Enable UFW
sudo ufw enable

# Allow SSH, HTTP, HTTPS
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Optional: Allow specific challenge ports
# sudo ufw allow 8001/tcp  # Example challenge port

# Verify rules
sudo ufw status
```

### 13. Setup Database Backups

```bash
# Create backup script
sudo tee /usr/local/bin/cyberlab-backup.sh > /dev/null << 'EOF'
#!/bin/bash
BACKUP_DIR="/var/backups/cyberlab"
DB_NAME="cyberlab_db"
DB_USER="cyberlab_user"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

mkdir -p "$BACKUP_DIR"
pg_dump -U "$DB_USER" -d "$DB_NAME" | gzip > "$BACKUP_DIR/cyberlab_backup_${TIMESTAMP}.sql.gz"
find "$BACKUP_DIR" -name "cyberlab_backup_*.sql.gz" -mtime +30 -delete
EOF

sudo chmod +x /usr/local/bin/cyberlab-backup.sh

# Setup cron job untuk daily backup pada 2 AM
echo "0 2 * * * /usr/local/bin/cyberlab-backup.sh" | sudo crontab -
```

### 14. Verify Installation

```bash
# Check services status
sudo systemctl status cyberlab-backend cyberlab-frontend nginx

# Check database
psql -U cyberlab_user -d cyberlab_db -h localhost -c "SELECT COUNT(*) FROM \"User\";"

# Check Redis
redis-cli ping

# Test API
curl -s http://localhost:3001/health | jq

# Access application
# Open browser: https://cyberlab.example.com
```

## 🔧 Post-Installation Configuration

### 1. Change Default Admin Password

```bash
# SSH ke server dan login ke admin panel
# Atau gunakan API:
curl -X POST https://cyberlab.example.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "Admin@123456"
  }'

# Gunakan response token untuk mengakses admin endpoints
```

### 2. Configure Email (Optional)

Edit `.env` dan tambahkan SMTP settings:

```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_FROM=noreply@cyberlab.example.com
```

Restart backend service setelah perubahan.

### 3. Customize Settings

Login sebagai admin dan akses `/admin/settings` untuk mengonfigurasi:
- Flag format
- Registrasi terbuka/tutup
- Kompetisi start/end time
- Theme colors
- Email settings

## 📊 Monitoring dan Maintenance

### Check System Resources

```bash
# CPU and Memory
top -b -n 1 | head -20

# Disk usage
df -h

# Services status
systemctl status cyberlab-backend cyberlab-frontend

# Database size
sudo -u postgres psql -c "\l+ cyberlab_db"
```

### View Logs

```bash
# Backend logs
sudo tail -f /var/www/cyberlab/logs/backend.log

# Frontend logs
sudo tail -f /var/www/cyberlab/logs/frontend.log

# Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# systemd journal
sudo journalctl -u cyberlab-backend -f
```

### Database Maintenance

```bash
# Backup database
sudo /usr/local/bin/cyberlab-backup.sh

# Analyze database
sudo -u postgres psql -d cyberlab_db -c "ANALYZE;"

# Vacuum (cleanup)
sudo -u postgres psql -d cyberlab_db -c "VACUUM ANALYZE;"
```

### Update Applications

```bash
# Stop services
sudo systemctl stop cyberlab-backend cyberlab-frontend

# Pull latest code
cd /var/www/cyberlab
sudo -u cyberlab git pull

# Update backend
cd backend
sudo -u cyberlab npm install --production
sudo -u cyberlab npm run build
sudo -u cyberlab npm run prisma:migrate:deploy

# Update frontend
cd ../frontend
sudo -u cyberlab npm install --production
sudo -u cyberlab npm run build

# Start services
sudo systemctl start cyberlab-backend cyberlab-frontend
```

## ⚠️ Troubleshooting

### Service not starting

```bash
# Check logs
sudo journalctl -u cyberlab-backend -n 50
sudo journalctl -u cyberlab-frontend -n 50

# Check permissions
ls -la /var/www/cyberlab/
sudo chown -R cyberlab:cyberlab /var/www/cyberlab

# Check port availability
sudo lsof -i :3001
sudo lsof -i :3000
```

### Database connection error

```bash
# Test PostgreSQL connection
psql -U cyberlab_user -d cyberlab_db -h localhost

# Check PostgreSQL listen address
sudo grep listen_addresses /etc/postgresql/14/main/postgresql.conf

# Restart PostgreSQL
sudo systemctl restart postgresql
```

### Nginx reverse proxy issues

```bash
# Test Nginx config
sudo nginx -t

# Check if backend/frontend are running
sudo systemctl status cyberlab-backend cyberlab-frontend

# Check Nginx error log
sudo tail -f /var/log/nginx/error.log
```

### High CPU/Memory usage

```bash
# Identify process using resources
top

# Check Node.js memory
ps aux | grep node

# Restart services to free memory
sudo systemctl restart cyberlab-backend cyberlab-frontend
```

## 🔒 Security Best Practices

1. **Change default admin password immediately** setelah instalasi
2. **Setup firewall** dengan UFW - buka minimal ports
3. **Enable HTTPS** dengan Certbot SSL
4. **Regular backups** - setup cron untuk daily backup
5. **Monitor logs** untuk suspicious activity
6. **Keep system updated** - `apt update && apt upgrade`
7. **Restrict database access** ke localhost only
8. **Use strong passwords** untuk semua services
9. **Setup fail2ban** untuk additional protection
10. Lihat [SECURITY_CHECKLIST.md](./SECURITY_CHECKLIST.md) untuk lengkap

## 📞 Support

Untuk troubleshooting dan support:
- Check logs di `/var/www/cyberlab/logs/`
- Check systemd journal: `journalctl -u cyberlab-*`
- Review Nginx logs: `/var/log/nginx/`
- Konsultasi dokumentasi di `/var/www/cyberlab/docs/`

---

**Installation Complete!** 🎉

Platform CyberLab Arena siap digunakan di `https://cyberlab.example.com`
