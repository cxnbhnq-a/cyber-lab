# CyberLab Arena - CTF Platform (Dark Cyberpunk Theme)

Sebuah platform CTF/lab cybersecurity modern dengan desain dark cyberpunk glassmorphism yang dirancang untuk deployment native di Ubuntu Server.

## 🎯 Fitur Utama

- **Dark Cyberpunk UI** dengan glassmorphism, neon glow, dan animasi smooth
- **Responsive design** untuk desktop dan mobile
- **User Management** dengan role-based access control (RBAC)
- **Challenge Management** dengan dynamic scoring
- **Scoreboard** real-time dengan ranking
- **Hint System** dengan cost/point deduction
- **Admin Dashboard** untuk mengelola challenges, users, dan settings
- **Security First** mengikuti OWASP ASVS Level 2, OWASP Top 10, dan NIST CSF
- **Production Ready** dengan deployment native di Ubuntu (bukan Docker)

## 📋 Tech Stack

### Frontend
- **Framework**: Next.js 14 + TypeScript
- **Styling**: Tailwind CSS dengan custom dark cyberpunk theme
- **Animation**: Framer Motion
- **UI Components**: Custom components dengan Lucide React icons
- **Form**: React Hook Form + Zod validation
- **HTTP Client**: Axios dengan interceptors

### Backend
- **Framework**: NestJS + TypeScript
- **Database**: PostgreSQL
- **ORM**: Prisma
- **Cache/Session**: Redis
- **Authentication**: JWT + secure cookies
- **Password Hashing**: Argon2id
- **API Documentation**: Swagger/OpenAPI
- **Validation**: class-validator + Zod

### Deployment
- **Web Server**: Nginx (reverse proxy)
- **Process Manager**: systemd service
- **OS**: Ubuntu Server 22.04 LTS
- **Database**: PostgreSQL (native install)
- **Cache**: Redis (native install)
- **Reverse Proxy**: Nginx

## 🚀 Quick Start (Development)

### Prerequisites
- Node.js 18+ dan npm
- PostgreSQL 14+
- Redis 7+

### Setup Backend

```bash
cd backend

# Install dependencies
npm install

# Setup environment
cp .env.example .env
# Edit .env dengan database dan Redis credentials lokal

# Generate Prisma client
npm run prisma:generate

# Run migrations
npm run prisma:migrate:dev

# Seed database dengan admin dan dummy data
npm run prisma:seed

# Start development server
npm run start:dev
```

Backend akan berjalan di `http://localhost:3001`
API docs tersedia di `http://localhost:3001/api/docs`

### Setup Frontend

```bash
cd frontend

# Install dependencies
npm install

# Create environment file
cat > .env.local << EOF
NEXT_PUBLIC_API_URL=http://localhost:3001/api
EOF

# Start development server
npm run dev
```

Frontend akan berjalan di `http://localhost:3000`

### Login ke Development Environment

Username: `admin`
Password: `Admin@123456`

## 📦 Project Structure

```
cyberlab-arena/
├── frontend/                      # Next.js application
│   ├── src/
│   │   ├── app/                  # App router pages
│   │   ├── components/           # Reusable components
│   │   ├── lib/                  # Utilities (auth, api-client, etc)
│   │   └── styles/               # Global styles
│   ├── package.json
│   ├── tailwind.config.js
│   ├── next.config.js
│   └── tsconfig.json
│
├── backend/                       # NestJS application
│   ├── src/
│   │   ├── auth/                 # Authentication module
│   │   ├── challenges/           # Challenges module
│   │   ├── scoreboard/           # Scoreboard module
│   │   ├── admin/                # Admin module
│   │   ├── common/               # Shared utilities
│   │   ├── config/               # Configuration
│   │   ├── database/             # Database module (Prisma)
│   │   ├── main.ts               # Entry point
│   │   └── app.module.ts         # Root module
│   ├── prisma/
│   │   ├── schema.prisma         # Database schema
│   │   ├── seed.ts               # Database seeding
│   │   └── migrations/           # Migration files
│   ├── test/                     # E2E tests
│   ├── package.json
│   └── tsconfig.json
│
├── nginx/                        # Nginx configuration
│   └── cyberlab.conf            # Production config
│
├── systemd/                      # systemd service files
│   ├── cyberlab-backend.service
│   └── cyberlab-frontend.service
│
├── scripts/                      # Deployment scripts
│   ├── install-server.sh        # Initial server setup
│   ├── deploy.sh                # Deployment script
│   ├── backup-db.sh             # Database backup
│   └── restore-db.sh            # Database restore
│
├── docs/                         # Documentation
│   ├── DEPLOYMENT_UBUNTU.md     # Step-by-step deployment guide
│   ├── SECURITY_CHECKLIST.md    # Security best practices
│   ├── CHALLENGE_DOCKER_GUIDE.md # Running challenges in Docker
│   └── API_DOCS.md              # API documentation
│
├── docker-examples/              # Example Docker setups (untuk challenges only)
│   └── challenges/
│
├── .env.example                 # Environment template
└── README.md                    # This file
```

## 🔒 Security Features

### Authentication & Authorization
- ✅ Argon2id password hashing dengan 65540 memory cost
- ✅ JWT dengan refresh token rotation
- ✅ Secure HttpOnly cookies
- ✅ Login rate limiting (5 attempts per 15 minutes per IP)
- ✅ Session management dengan server-side validation
- ✅ RBAC: USER, MODERATOR, ADMIN, SUPERADMIN
- ✅ Token revocation dan logout

### Input Validation & CSRF Protection
- ✅ Backend validation untuk semua input menggunakan class-validator dan Zod
- ✅ CSRF token untuk cookie-based auth
- ✅ SameSite cookie setting (Lax)
- ✅ Sanitasi markdown dan output encoding
- ✅ Type-safe DTOs dengan TypeScript

### API Security
- ✅ Rate limiting (100 requests per 15 minutes)
- ✅ Strict CORS allowlist
- ✅ Security headers:
  - Content-Security-Policy
  - Strict-Transport-Security (HSTS)
  - X-Frame-Options
  - X-Content-Type-Options
  - Referrer-Policy
- ✅ Request body size limit
- ✅ Helmet.js middleware

### Data Protection
- ✅ Constant-time flag comparison
- ✅ Soft delete untuk challenges (audit trail)
- ✅ Audit logging untuk semua admin actions
- ✅ Database dengan least privilege principles
- ✅ No raw SQL queries (Prisma ORM protection)
- ✅ Environment variables untuk secrets

### Upload Security
- ✅ File type whitelist validation
- ✅ File size limits (max 100MB)
- ✅ Random UUID renaming untuk uploaded files
- ✅ Storage di non-executable directory
- ✅ MIME type verification di backend
- ✅ No direct execution via web server

## 📖 Documentation

Lihat dokumentasi lengkap di folder `docs/`:

- [DEPLOYMENT_UBUNTU.md](./docs/DEPLOYMENT_UBUNTU.md) - Panduan deployment step-by-step
- [SECURITY_CHECKLIST.md](./docs/SECURITY_CHECKLIST.md) - Security best practices dan checklist
- [CHALLENGE_DOCKER_GUIDE.md](./docs/CHALLENGE_DOCKER_GUIDE.md) - Menjalankan challenges di Docker
- [API_DOCS.md](./docs/API_DOCS.md) - API endpoints documentation

## 🧪 Testing

```bash
# Backend tests
cd backend
npm run test                  # Unit tests
npm run test:cov             # Coverage report
npm run test:e2e             # E2E tests dengan database

# Frontend tests
cd frontend
npm run test                  # Jest tests
npm run e2e                   # Playwright E2E tests
npm run e2e:ui               # UI mode dengan debug
```

## 📊 Database Schema

Platform menggunakan PostgreSQL dengan Prisma ORM. Key tables:

- **users** - User accounts dengan hashing password
- **teams** - Team management untuk kompetisi
- **challenges** - CTF challenges dengan metadata
- **categories** - Challenge categories (Web, Pwn, Crypto, dll)
- **flags** - Multiple flags per challenge dengan regex support
- **hints** - Hints dengan point cost
- **submissions** - Flag submission tracking
- **solves** - Challenge solves dengan dynamic scoring
- **audit_logs** - Admin action logging
- **settings** - Platform configuration

Lihat [schema.prisma](./backend/prisma/schema.prisma) untuk detail lengkap.

## 🚀 Deployment

### Native Ubuntu Server Deployment (TIDAK DOCKER)

Deployment platform utama menggunakan:
- Nginx sebagai reverse proxy
- systemd untuk process management
- PostgreSQL native di server
- Redis native di server

**Instalasi cepat:**

```bash
# 1. Clone repository
git clone <repo-url> /var/www/cyberlab
cd /var/www/cyberlab

# 2. Run installation script
sudo bash scripts/install-server.sh

# 3. Configure environment
sudo cp .env.example /var/www/cyberlab/.env
sudo nano /var/www/cyberlab/.env  # Edit konfigurasi

# 4. Deploy
sudo bash scripts/deploy.sh

# 5. Setup HTTPS dengan Certbot
sudo certbot certonly --nginx -d cyberlab.example.com
```

Untuk deployment detail, lihat [DEPLOYMENT_UBUNTU.md](./docs/DEPLOYMENT_UBUNTU.md)

### Docker untuk Challenges SAJA

Docker hanya digunakan untuk menjalankan challenges terpisah (web services, pwn challenges, nc services) di `/opt/ctf-challenges/`.

**Platform utama TIDAK menggunakan Docker** - berjalan native di server dengan:
- Backend: systemd service untuk NestJS
- Frontend: systemd service untuk Next.js
- Database & Cache: Native PostgreSQL & Redis
- Web Server: Nginx sebagai reverse proxy

Lihat [CHALLENGE_DOCKER_GUIDE.md](./docs/CHALLENGE_DOCKER_GUIDE.md) untuk menjalankan challenges.

## 🔧 Admin Panel

Akses admin panel di `https://cyberlab.example.com/admin` setelah login sebagai admin user.

Fitur admin:
- 📊 Dashboard dengan statistics
- 🎯 Manage challenges (CRUD, upload attachment, configure flags & hints)
- 👥 Manage users (ban, reset password, change role)
- 📁 Manage categories
- 🏆 Manage scoreboard (freeze, hide, export CSV)
- ⚙️ System settings (flag format, registration, competition time)
- 📋 View audit logs
- 📤 Export submissions dan scoreboard

## 🎨 Frontend Features

### Pages
1. **Landing** - Hero dengan CTA login/register
2. **Auth** - Login dan register pages
3. **Dashboard** - User progress dan stats
4. **Challenges** - List dengan filter kategori/difficulty/search
5. **Challenge Detail** - Deskripsi, attachment download, service info, submit flag, hints
6. **Scoreboard** - Ranking dengan real-time updates
7. **Profile** - User profile dan solved challenges
8. **Admin** - Dashboard, manage resources, view logs

### UI/UX
- Dark cyberpunk glassmorphism design
- Neon glowing borders dan typography
- Smooth animations dengan Framer Motion
- Loading skeletons dan skeleton screens
- Toast notifications untuk feedback
- Modal dialogs untuk critical actions
- Responsive grid layouts
- Animated background dengan grid pattern
- Real-time updates untuk scoreboard
- Mobile-first responsive design

## 📱 API Endpoints

### Authentication
- `POST /auth/register` - Register user baru
- `POST /auth/login` - Login dengan username/email
- `POST /auth/logout` - Logout
- `GET /auth/me` - Get current user info
- `POST /auth/change-password` - Change password

### Challenges
- `GET /challenges` - List challenges (dengan filter)
- `GET /challenges/:id` - Get challenge detail
- `POST /challenges/:id/submit` - Submit flag
- `POST /challenges/:id/hints/:hintId/unlock` - Unlock hint

### Scoreboard
- `GET /scoreboard` - Get global scoreboard
- `GET /scoreboard/me` - Get user scoreboard
- `GET /scoreboard/me/category-stats` - Category statistics

### Admin
- `GET /admin/stats` - Dashboard statistics
- `CRUD /admin/challenges` - Manage challenges
- `CRUD /admin/users` - Manage users
- `CRUD /admin/categories` - Manage categories
- `GET /admin/submissions` - View all submissions
- `GET /admin/audit-logs` - View audit logs
- `PATCH /admin/settings` - Update settings

Lihat [API_DOCS.md](./docs/API_DOCS.md) untuk dokumentasi lengkap.

## 🛠️ Development

### Code Style
- ESLint untuk JavaScript/TypeScript
- Prettier untuk code formatting
- Git pre-commit hooks dengan husky (opsional)

### Best Practices
- Type-safe dengan TypeScript strict mode
- Error handling dengan try-catch dan proper logging
- Environment variables untuk configuration
- Modular architecture dengan separation of concerns
- Service layer pattern di backend
- Custom hooks untuk logic reuse di frontend

### Adding New Features

1. **Backend**: Buat feature dalam module baru (di `src/`), tambah ke `app.module.ts`
2. **Frontend**: Buat components di `src/components/`, pages di `src/app/`
3. **Database**: Update schema.prisma, jalankan `npm run prisma:migrate:dev`
4. **Tests**: Tambah tests di `__tests__/` folder

## 📝 Environment Variables

Lihat [.env.example](./.env.example) untuk konfigurasi lengkap:

```env
# Application
NODE_ENV=production
APP_URL=https://cyberlab.example.com
API_URL=https://cyberlab.example.com/api

# Database
DATABASE_URL="postgresql://user:password@localhost:5432/cyberlab"

# Redis
REDIS_URL="redis://localhost:6379/0"

# JWT
JWT_SECRET=your_jwt_secret_minimum_256_bits
JWT_EXPIRE_IN=7d

# Security
RATE_LIMIT_MAX_REQUESTS=100
LOGIN_RATE_LIMIT_MAX_REQUESTS=5

# Upload
UPLOAD_DIR=/var/www/cyberlab/uploads
MAX_FILE_SIZE=104857600

# Email (optional)
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=your-email@example.com

# Admin
ADMIN_EMAIL=admin@cyberlab.example.com
ADMIN_PASSWORD=ChangeMe123!
```

## 🤝 Contributing

Kontribusi dan feedback welcome! Please:

1. Fork repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

MIT License - see LICENSE file for details

## 👥 Support & Contact

Untuk issues, questions, atau suggestions:
- 📧 Email: support@cyberlab.local
- 🐛 Issues: GitHub Issues
- 💬 Discussions: GitHub Discussions

## ⚠️ Important Security Notes

1. **JANGAN jalankan platform utama dengan Docker** - gunakan native Ubuntu server
2. **Selalu update dependencies** dengan `npm audit fix`
3. **Enable HTTPS** dengan Certbot SSL di production
4. **Setup firewall** dengan UFW - buka hanya port 22, 80, 443
5. **Regular backups** database dengan script `backup-db.sh`
6. **Monitor logs** di `/var/www/cyberlab/logs/`
7. **Change default admin password** segera setelah deployment
8. **Keep systems updated** - `apt update && apt upgrade`

Untuk checklist security lengkap, lihat [SECURITY_CHECKLIST.md](./docs/SECURITY_CHECKLIST.md)

---

**CyberLab Arena** © 2024 - Secure CTF Platform for Everyone 🚀
