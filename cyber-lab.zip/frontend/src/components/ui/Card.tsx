import React from 'react';
import clsx from 'clsx';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  variant?: 'default' | 'neon' | 'elevated';
  hoverable?: boolean;
}

export const Card = React.forwardRef<HTMLDivElement, CardProps>(
  ({ className, children, variant = 'default', hoverable = false, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={clsx(
          'rounded-lg p-6',
          variant === 'default' && 'card-glass',
          variant === 'neon' && 'neon-border-animated bg-black bg-opacity-40',
          variant === 'elevated' && 'card-glass shadow-neon',
          hoverable && 'card-glass-hover hover:scale-105',
          'transition-all duration-300',
          className,
        )}
        {...props}
      >
        {children}
      </div>
    );
  },
);

Card.displayName = 'Card';
