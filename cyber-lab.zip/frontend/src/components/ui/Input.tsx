import React from 'react';
import clsx from 'clsx';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  icon?: React.ReactNode;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, error, helperText, icon, type = 'text', ...props }, ref) => {
    return (
      <div className="w-full">
        {label && (
          <label className="block text-sm font-semibold mb-2 text-neon-cyan">
            {label}
          </label>
        )}
        <div className="relative">
          {icon && <div className="absolute left-3 top-1/2 -translate-y-1/2">{icon}</div>}
          <input
            ref={ref}
            type={type}
            className={clsx(
              'w-full px-4 py-2.5 rounded-lg',
              'bg-cyber-card border border-neon-purple border-opacity-30',
              'text-white placeholder-gray-400',
              'focus:outline-none focus:border-neon-cyan focus:ring-2 focus:ring-neon-purple focus:ring-opacity-50',
              'transition-all duration-300',
              icon && 'pl-10',
              error && 'border-red-500 border-opacity-100',
              className,
            )}
            {...props}
          />
        </div>
        {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
        {helperText && !error && <p className="text-gray-400 text-sm mt-1">{helperText}</p>}
      </div>
    );
  },
);

Input.displayName = 'Input';
