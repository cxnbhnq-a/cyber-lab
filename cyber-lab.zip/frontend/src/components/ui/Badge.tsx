import React from 'react';
import clsx from 'clsx';

interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  children: React.ReactNode;
  variant?: 'easy' | 'medium' | 'hard' | 'insane' | 'success' | 'danger' | 'info' | 'warning';
}

const variantClasses = {
  easy: 'bg-green-500 bg-opacity-20 text-green-300 border-green-500',
  medium: 'bg-yellow-500 bg-opacity-20 text-yellow-300 border-yellow-500',
  hard: 'bg-orange-500 bg-opacity-20 text-orange-300 border-orange-500',
  insane: 'bg-red-500 bg-opacity-20 text-red-300 border-red-500',
  success: 'bg-green-500 bg-opacity-20 text-green-300 border-green-500',
  danger: 'bg-red-500 bg-opacity-20 text-red-300 border-red-500',
  info: 'bg-blue-500 bg-opacity-20 text-blue-300 border-blue-500',
  warning: 'bg-yellow-500 bg-opacity-20 text-yellow-300 border-yellow-500',
};

export const Badge = React.forwardRef<HTMLSpanElement, BadgeProps>(
  ({ className, children, variant = 'info', ...props }, ref) => (
    <span
      ref={ref}
      className={clsx(
        'inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold border',
        variantClasses[variant],
        className,
      )}
      {...props}
    >
      {children}
    </span>
  ),
);

Badge.displayName = 'Badge';
