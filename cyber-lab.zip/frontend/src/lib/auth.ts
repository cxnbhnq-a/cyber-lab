import Cookies from 'js-cookie';

export interface Session {
  user: {
    id: string;
    username: string;
    email: string;
    displayName: string;
    role: string;
  };
  accessToken: string;
  refreshToken: string;
}

const SESSION_STORAGE_KEY = 'cyberlab_session';
const SESSION_EXPIRY_KEY = 'cyberlab_session_expiry';

export async function setSession(session: Session): Promise<void> {
  // Store session in localStorage
  localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));

  // Set expiry time (7 days)
  const expiryTime = new Date().getTime() + 7 * 24 * 60 * 60 * 1000;
  localStorage.setItem(SESSION_EXPIRY_KEY, expiryTime.toString());

  // Set secure cookie for backend
  Cookies.set('accessToken', session.accessToken, {
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    expires: 7,
  });

  Cookies.set('refreshToken', session.refreshToken, {
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    expires: 30,
  });
}

export async function getSession(): Promise<Session | null> {
  if (typeof window === 'undefined') {
    return null;
  }

  try {
    const sessionStr = localStorage.getItem(SESSION_STORAGE_KEY);
    const expiryStr = localStorage.getItem(SESSION_EXPIRY_KEY);

    if (!sessionStr || !expiryStr) {
      return null;
    }

    // Check if session has expired
    const expiryTime = parseInt(expiryStr);
    if (new Date().getTime() > expiryTime) {
      await clearSession();
      return null;
    }

    return JSON.parse(sessionStr) as Session;
  } catch (error) {
    console.error('Failed to get session:', error);
    return null;
  }
}

export async function clearSession(): Promise<void> {
  localStorage.removeItem(SESSION_STORAGE_KEY);
  localStorage.removeItem(SESSION_EXPIRY_KEY);
  Cookies.remove('accessToken');
  Cookies.remove('refreshToken');
}

export async function signOut(): Promise<void> {
  await clearSession();
  // Redirect to login
  if (typeof window !== 'undefined') {
    window.location.href = '/auth/login';
  }
}

export function isAuthenticated(): boolean {
  if (typeof window === 'undefined') {
    return false;
  }

  return localStorage.getItem(SESSION_STORAGE_KEY) !== null;
}

export async function getCurrentUser(): Promise<Session['user'] | null> {
  const session = await getSession();
  return session?.user || null;
}
