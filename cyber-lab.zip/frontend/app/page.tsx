import Link from 'next/link';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';

export default function HomePage() {
  return (
    <div className="space-y-10">
      <section className="rounded-[2rem] border border-white/10 bg-[rgba(255,255,255,0.04)] p-10 shadow-neon">
        <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
          <div>
            <p className="mb-4 text-sm uppercase tracking-[0.4em] text-neon-cyan/80">CyberLab Arena</p>
            <h1 className="text-4xl font-extrabold leading-tight text-white md:text-5xl">
              Command the CTF battlefield with neon precision.
            </h1>
            <p className="mt-6 max-w-2xl text-sm text-gray-300 sm:text-base">
              Practice real-world offensive and defensive challenges inside a polished cyberpunk capture-the-flag platform.
              Track your team, unlock hints, and compete with live scoreboards.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/challenges">
                <Button>Browse Challenges</Button>
              </Link>
              <Link href="/auth/login">
                <Button variant="secondary">Sign In</Button>
              </Link>
            </div>
          </div>
          <Card className="bg-[#090b18] p-8">
            <div className="space-y-4">
              <p className="text-sm uppercase tracking-[0.4em] text-neon-purple/70">Arena Status</p>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4">2024 CTF Season</div>
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4">Live score updates</div>
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4">Team leaderboards</div>
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4">Secure challenge sandboxing</div>
              </div>
            </div>
          </Card>
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-3">
        {[
          { title: 'Competitive scoring', description: 'Real-time ranking, penalty timers, and dynamic challenge points.' },
          { title: 'Secure challenge delivery', description: 'Sandboxed services with hardened infrastructure and audit logging.' },
          { title: 'Advanced admin tools', description: 'Manage teams, challenges, and events from a centralized dashboard.' },
        ].map((feature) => (
          <Card key={feature.title} className="space-y-3 bg-black/40">
            <h2 className="text-xl font-semibold text-white">{feature.title}</h2>
            <p className="text-sm text-gray-300">{feature.description}</p>
          </Card>
        ))}
      </section>
    </div>
  );
}
