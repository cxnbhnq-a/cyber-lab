'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { apiClient } from '@/lib/api-client';

export default function RegisterPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setSuccess(null);

    if (password.length < 12) {
      setError('Password must be at least 12 characters.');
      return;
    }

    setIsLoading(true);

    try {
      await apiClient.post('/auth/register', {
        username,
        email,
        password,
      });

      setSuccess('Registration successful. You may now log in.');
      setUsername('');
      setEmail('');
      setPassword('');
      setTimeout(() => router.push('/auth/login'), 1200);
    } catch (error: any) {
      setError(error?.response?.data?.message ?? 'Unable to register account.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl">
      <Card className="space-y-6 bg-black/60 p-8">
        <div className="space-y-3">
          <p className="text-sm uppercase tracking-[0.4em] text-neon-purple/80">Create your team</p>
          <h1 className="text-3xl font-semibold text-white">Register</h1>
          <p className="text-sm text-gray-300">Create a new account to join the CyberLab Arena leaderboard.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <Input
            label="Username"
            name="username"
            value={username}
            onChange={(event) => setUsername(event.target.value)}
            placeholder="Choose a handle"
            required
          />
          <Input
            label="Email"
            type="email"
            name="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="you@example.com"
            required
          />
          <Input
            label="Password"
            type="password"
            name="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            placeholder="Create a strong password"
            helperText="Minimum 12 characters"
            required
          />

          {error && <p className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-200">{error}</p>}
          {success && <p className="rounded-lg border border-green-500/30 bg-green-500/10 p-3 text-sm text-green-200">{success}</p>}

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <Button type="submit" isLoading={isLoading}>Register</Button>
            <Link href="/auth/login" className="text-sm text-neon-cyan hover:text-white">
              Already registered?
            </Link>
          </div>
        </form>
      </Card>
    </div>
  );
}
