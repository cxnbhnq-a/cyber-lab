'use client';

import { useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { apiClient } from '@/lib/api-client';
import { setSession } from '@/lib/auth';

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const response = await apiClient.post('/auth/login', {
        username,
        password,
      });

      await setSession(response.data);
      router.push('/challenges');
    } catch (error: any) {
      setError(error?.response?.data?.message ?? 'Invalid credentials');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl">
      <Card className="space-y-6 bg-black/60 p-8">
        <div className="space-y-3">
          <p className="text-sm uppercase tracking-[0.4em] text-neon-cyan/80">Member Login</p>
          <h1 className="text-3xl font-semibold text-white">Login</h1>
          <p className="text-sm text-gray-300">Enter your credentials to access the CyberLab Arena platform.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <Input
            label="Username"
            name="username"
            value={username}
            onChange={(event) => setUsername(event.target.value)}
            placeholder="Enter your username"
            required
          />
          <Input
            type="password"
            label="Password"
            name="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            placeholder="Enter your password"
            required
          />

          {error && <p className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-200">{error}</p>}

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <Button type="submit" isLoading={isLoading}>Login</Button>
            <Link href="/auth/register" className="text-sm text-neon-cyan hover:text-white">
              Need an account?
            </Link>
          </div>
        </form>
      </Card>
    </div>
  );
}
