'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { apiClient } from '@/lib/api-client';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';

interface AdminStats {
  totalUsers: number;
  totalChallenges: number;
  totalSubmissions: number;
}

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadStats = async () => {
      try {
        const response = await apiClient.get('/admin/stats');
        setStats(response.data);
      } catch (err) {
        setError('Unable to load admin stats.');
      }
    };

    loadStats();
  }, []);

  return (
    <div className="space-y-8">
      <div>
        <p className="text-sm uppercase tracking-[0.4em] text-neon-cyan/80">Admin Control</p>
        <h1 className="text-4xl font-bold text-white">Admin Dashboard</h1>
        <p className="mt-3 max-w-2xl text-gray-300">Manage users, challenges, and event settings from a centralized admin console.</p>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.4fr_0.9fr]">
        <Card className="grid gap-4 bg-black/60 p-6">
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="rounded-2xl border border-white/10 bg-cyber-card p-5">
              <p className="text-sm uppercase tracking-[0.3em] text-gray-400">Total Users</p>
              <p className="mt-3 text-3xl font-semibold text-neon-cyan">{stats?.totalUsers ?? '—'}</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-cyber-card p-5">
              <p className="text-sm uppercase tracking-[0.3em] text-gray-400">Total Challenges</p>
              <p className="mt-3 text-3xl font-semibold text-neon-purple">{stats?.totalChallenges ?? '—'}</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-cyber-card p-5">
              <p className="text-sm uppercase tracking-[0.3em] text-gray-400">Submissions</p>
              <p className="mt-3 text-3xl font-semibold text-neon-cyan">{stats?.totalSubmissions ?? '—'}</p>
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-black/30 p-5 text-sm text-gray-300">
            <p>Use the navigation links to manage challenge content and user permissions.</p>
            {error && <p className="mt-3 text-red-400">{error}</p>}
          </div>
        </Card>

        <Card className="space-y-4 bg-black/60 p-6">
          <p className="text-lg font-semibold text-white">Quick actions</p>
          <div className="grid gap-3">
            <Link href="/admin/challenges">
              <Button variant="secondary">Manage Challenges</Button>
            </Link>
            <Link href="/admin/users">
              <Button variant="secondary">Manage Users</Button>
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
