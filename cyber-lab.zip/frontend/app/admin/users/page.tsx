import { Card } from '@/components/ui/Card';

export default function AdminUsersPage() {
  return (
    <div className="space-y-8">
      <div>
        <p className="text-sm uppercase tracking-[0.4em] text-neon-purple/80">Admin</p>
        <h1 className="text-4xl font-bold text-white">Users</h1>
        <p className="mt-3 max-w-2xl text-gray-300">Review registered users and manage permissions from the admin console.</p>
      </div>

      <Card className="bg-black/60 p-6">
        <p className="text-sm text-gray-300">A complete user management interface is available through the admin dashboard.</p>
      </Card>
    </div>
  );
}
