import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import Link from 'next/link';

export default function NewAdminChallengePage() {
  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-sm uppercase tracking-[0.4em] text-neon-cyan/80">New Challenge</p>
          <h1 className="text-4xl font-bold text-white">Create Challenge</h1>
          <p className="mt-3 max-w-2xl text-gray-300">Draft a new challenge and configure its scoring, category, and hints.</p>
        </div>
        <Link href="/admin/challenges">
          <Button variant="secondary">Back to challenges</Button>
        </Link>
      </div>

      <Card className="bg-black/60 p-6">
        <p className="text-sm text-gray-300">This interface is a stub for the new challenge workflow. The full admin creation flow is implemented on the backend.</p>
      </Card>
    </div>
  );
}
