import Link from 'next/link';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';

export default function AdminChallengesPage() {
  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-sm uppercase tracking-[0.4em] text-neon-cyan/80">Admin</p>
          <h1 className="text-4xl font-bold text-white">Challenges</h1>
          <p className="mt-3 max-w-2xl text-gray-300">Review and manage contest challenge content from the admin console.</p>
        </div>
        <Link href="/admin/challenges/new">
          <Button>New Challenge</Button>
        </Link>
      </div>

      <Card className="bg-black/60 p-6">
        <p className="text-sm text-gray-300">Manage challenge metadata, category mapping, hints, and scoring settings.</p>
      </Card>
    </div>
  );
}
