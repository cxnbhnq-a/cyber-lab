import './globals.css';
import Link from 'next/link';

export const metadata = {
  title: 'CyberLab Arena',
  description: 'Cyberpunk-themed CTF platform for competitive cybersecurity events.',
};

const navLinks = [
  { href: '/', label: 'Home' },
  { href: '/challenges', label: 'Challenges' },
  { href: '/scoreboard', label: 'Scoreboard' },
  { href: '/admin', label: 'Admin' },
  { href: '/auth/login', label: 'Login' },
  { href: '/auth/register', label: 'Register' },
];

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-cyber-darker text-white">
        <div className="relative min-h-screen overflow-hidden">
          <header className="border-b border-white/10 bg-black/30 backdrop-blur-xl">
            <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-5 md:flex-row md:items-center md:justify-between">
              <Link href="/" className="text-2xl font-extrabold tracking-tight text-neon-purple">
                CyberLab Arena
              </Link>
              <nav className="flex flex-wrap items-center gap-3 text-sm text-white/75">
                {navLinks.map((link) => (
                  <Link
                    key={link.href}
                    href={link.href}
                    className="rounded-full border border-white/10 px-4 py-2 transition hover:border-neon-cyan hover:text-white"
                  >
                    {link.label}
                  </Link>
                ))}
              </nav>
            </div>
          </header>
          <main className="mx-auto max-w-7xl px-4 py-10">{children}</main>
        </div>
      </body>
    </html>
  );
}
