'use client';

import { useEffect, useState, type FormEvent } from 'react';
import { useParams } from 'next/navigation';
import { apiClient } from '@/lib/api-client';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Input } from '@/components/ui/Input';
import Link from 'next/link';

interface ChallengeDetail {
  id: string;
  title: string;
  description: string;
  difficulty: string;
  points: number;
  solveCount: number;
  isSolved: boolean;
  category?: { name: string };
  author?: { username: string; displayName?: string };
  serviceUrl?: string;
  ncHost?: string;
  ncPort?: number;
  tags?: string[];
}

export default function ChallengeDetailPage() {
  const params = useParams();
  const challengeId = typeof params === 'object' ? params.id : params;

  const [challenge, setChallenge] = useState<ChallengeDetail | null>(null);
  const [flag, setFlag] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const loadChallenge = async () => {
      if (!challengeId) return;
      setError(null);
      setIsLoading(true);

      try {
        const response = await apiClient.get(`/challenges/${challengeId}`);
        setChallenge(response.data);
      } catch (error: any) {
        setError(error?.response?.data?.message ?? 'Unable to load challenge.');
      } finally {
        setIsLoading(false);
      }
    };

    loadChallenge();
  }, [challengeId]);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setMessage(null);
    setError(null);
    if (!challengeId || flag.trim().length === 0) {
      setError('Please enter a flag.');
      return;
    }

    setIsLoading(true);
    try {
      const response = await apiClient.post(`/challenges/${challengeId}/submit`, { flag });
      setMessage(response.data.message ?? (response.data.isCorrect ? 'Flag accepted!' : 'Incorrect flag.'));
      if (!response.data.isCorrect) {
        setError('Incorrect flag.');
      }
    } catch (error: any) {
      setError(error?.response?.data?.message ?? 'Unable to submit the flag.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm uppercase tracking-[0.4em] text-neon-purple/80">Challenge detail</p>
          <h1 className="text-4xl font-bold text-white">{challenge?.title || 'Challenge'}</h1>
        </div>
        <Link href="/challenges" className="text-sm text-neon-cyan hover:text-white">
          &larr; Back to challenges
        </Link>
      </div>

      {error && <p className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-200">{error}</p>}

      <div className="grid gap-6 xl:grid-cols-[1.3fr_0.7fr]">
        <Card className="space-y-6 bg-black/60 p-8">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-sm uppercase tracking-[0.2em] text-gray-400">Difficulty</span>
            <Badge variant={challenge?.difficulty.toLowerCase() as any}>{challenge?.difficulty || 'Unknown'}</Badge>
            <span className="text-sm text-gray-400">{challenge?.points ?? 0} points</span>
            <span className="text-sm text-gray-400">{challenge?.solveCount ?? 0} solves</span>
          </div>

          <div className="space-y-4">
            <p className="text-lg font-semibold text-white">Description</p>
            <p className="text-sm leading-7 text-gray-300">{challenge?.description || 'No description available.'}</p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-2xl border border-white/10 bg-cyber-card p-4 text-sm text-gray-300">
              <p className="font-semibold text-white">Category</p>
              <p>{challenge?.category?.name || 'General'}</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-cyber-card p-4 text-sm text-gray-300">
              <p className="font-semibold text-white">Status</p>
              <p>{challenge?.isSolved ? 'Already solved' : 'Unsolved'}</p>
            </div>
          </div>
        </Card>

        <Card className="space-y-6 bg-black/60 p-8">
          <p className="text-lg font-semibold text-white">Submit Flag</p>
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="Flag"
              name="flag"
              value={flag}
              onChange={(event) => setFlag(event.target.value)}
              placeholder="Enter flag"
              required
            />
            <Button type="submit" isLoading={isLoading}>
              Submit Flag
            </Button>
          </form>
          {message && !error && <p className="rounded-lg border border-green-500/30 bg-green-500/10 p-3 text-sm text-green-200">{message}</p>}
          {error && <p className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-200">{error}</p>}
        </Card>
      </div>
    </div>
  );
}
