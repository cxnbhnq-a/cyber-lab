'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { apiClient } from '@/lib/api-client';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Input } from '@/components/ui/Input';

interface Challenge {
  id: string;
  title: string;
  description: string;
  difficulty: string;
  points: number;
  solveCount: number;
  isSolved?: boolean;
  category?: { name: string };
}

const categoryOptions = ['All', 'Web', 'Forensics', 'Crypto', 'Pwn', 'Misc'];
const difficultyOptions = ['All', 'Easy', 'Medium', 'Hard', 'Insane'];

export default function ChallengesPage() {
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [difficulty, setDifficulty] = useState('All');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadChallenges = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await apiClient.get('/challenges?limit=50');
        setChallenges(response.data.data || []);
      } catch (error: any) {
        setError(error?.response?.data?.message ?? 'Unable to load challenges.');
      } finally {
        setIsLoading(false);
      }
    };

    loadChallenges();
  }, []);

  const filteredChallenges = useMemo(() => {
    return challenges.filter((challenge) => {
      const text = `${challenge.title} ${challenge.description} ${challenge.category?.name ?? ''}`.toLowerCase();
      const matchesSearch = search.trim().length === 0 || text.includes(search.toLowerCase());
      const matchesCategory = category === 'All' || challenge.category?.name === category;
      const matchesDifficulty = difficulty === 'All' || challenge.difficulty === difficulty;
      return matchesSearch && matchesCategory && matchesDifficulty;
    });
  }, [challenges, category, difficulty, search]);

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="text-sm uppercase tracking-[0.4em] text-neon-cyan/80">Challenge Arena</p>
          <h1 className="text-4xl font-bold text-white">Challenges</h1>
          <p className="mt-3 max-w-2xl text-gray-300">Browse available CTF tasks across categories, difficulty tiers, and scoring modes.</p>
        </div>
        <Button variant="secondary">Filter</Button>
      </div>

      <Card className="grid gap-4 p-6 lg:grid-cols-[1fr_280px]">
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-3">
            <Input
              label="Search"
              name="search"
              placeholder="Search challenges"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
            <div>
              <label className="block text-sm font-semibold mb-2 text-neon-cyan">Category</label>
              <select
                className="w-full rounded-lg border border-neon-purple/30 bg-cyber-card px-4 py-2 text-white focus:border-neon-cyan focus:ring-2 focus:ring-neon-purple focus:ring-opacity-30"
                value={category}
                onChange={(event) => setCategory(event.target.value)}
              >
                {categoryOptions.map((option) => (
                  <option key={option} value={option}>{option}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2 text-neon-cyan">Difficulty</label>
              <select
                className="w-full rounded-lg border border-neon-purple/30 bg-cyber-card px-4 py-2 text-white focus:border-neon-cyan focus:ring-2 focus:ring-neon-purple focus:ring-opacity-30"
                value={difficulty}
                onChange={(event) => setDifficulty(event.target.value)}
              >
                {difficultyOptions.map((option) => (
                  <option key={option} value={option}>{option}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-black/30 p-4 text-sm text-gray-400">
            {isLoading ? 'Loading challenges...' : `${filteredChallenges.length} challenges available`}
          </div>
        </div>

        <div className="space-y-4 rounded-2xl border border-white/10 bg-black/30 p-6">
          <p className="font-semibold text-white">Quick filters</p>
          <div className="grid gap-3">
            <Button variant="ghost" onClick={() => setCategory('All')}>All Categories</Button>
            <Button variant="ghost" onClick={() => setDifficulty('All')}>All Difficulties</Button>
            <Button variant="ghost" onClick={() => setSearch('')}>Clear Search</Button>
          </div>
        </div>
      </Card>

      {error && <p className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-200">{error}</p>}

      <div className="grid gap-6 lg:grid-cols-2">
        {filteredChallenges.map((challenge) => (
          <Card
            key={challenge.id}
            className="group space-y-4 bg-black/40 transition hover:-translate-y-1 hover:shadow-neon"
            data-test="challenge-card"
          >
            <div className="flex items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-semibold text-white">{challenge.title}</h2>
                <p className="text-sm text-gray-400">{challenge.category?.name || 'General'}</p>
              </div>
              <Badge variant={challenge.difficulty.toLowerCase() as any}>{challenge.difficulty}</Badge>
            </div>
            <p className="text-sm leading-6 text-gray-300">{challenge.description || 'Solve the challenge and submit the correct flag.'}</p>
            <div className="flex flex-wrap items-center justify-between gap-3 text-sm text-gray-300">
              <span>{challenge.points} pts</span>
              <span>{challenge.solveCount} solves</span>
            </div>
            <Link href={`/challenges/${challenge.id}`} className="inline-flex text-sm font-semibold text-neon-cyan hover:text-white">
              View challenge
            </Link>
          </Card>
        ))}
      </div>

      {!isLoading && filteredChallenges.length === 0 && (
        <p className="rounded-2xl border border-white/10 bg-cyber-card p-6 text-center text-gray-300">No challenges matched your filters yet.</p>
      )}
    </div>
  );
}
