'use client';

import { useEffect, useState } from 'react';
import { apiClient } from '@/lib/api-client';
import { Card } from '@/components/ui/Card';

interface ScoreRow {
  id: string;
  rank: number;
  username: string;
  points: number;
  solved: number;
}

export default function ScoreboardPage() {
  const [rows, setRows] = useState<ScoreRow[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadScoreboard = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await apiClient.get('/scoreboard');
        setRows(
          (response.data.data || response.data || []).map((entry: any, index: number) => ({
            id: entry.id ?? `${index}`,
            rank: index + 1,
            username: entry.username || entry.user?.username || 'Unknown',
            points: entry.points || entry.score || 0,
            solved: entry.solvedCount || 0,
          })),
        );
      } catch (error: any) {
        setError(error?.response?.data?.message ?? 'Unable to load scoreboard.');
      } finally {
        setIsLoading(false);
      }
    };

    loadScoreboard();
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm uppercase tracking-[0.4em] text-neon-cyan/80">Live Rankings</p>
        <h1 className="text-4xl font-bold text-white">Scoreboard</h1>
        <p className="mt-3 max-w-2xl text-gray-300">Track the top competitors and stay ahead of the pack.</p>
      </div>

      {error && <p className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-200">{error}</p>}

      <Card className="overflow-hidden bg-black/60">
        <table className="min-w-full border-separate border-spacing-0 text-left text-sm text-gray-200">
          <thead>
            <tr className="border-b border-white/10 bg-white/5 text-gray-300">
              <th className="px-6 py-4">Rank</th>
              <th className="px-6 py-4">Player</th>
              <th className="px-6 py-4">Points</th>
              <th className="px-6 py-4">Solved</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr>
                <td colSpan={4} className="px-6 py-6 text-center text-gray-400">Loading scoreboard...</td>
              </tr>
            )}
            {!isLoading && rows.length === 0 && (
              <tr>
                <td colSpan={4} className="px-6 py-6 text-center text-gray-400">No scoreboard data available yet.</td>
              </tr>
            )}
            {rows.map((row) => (
              <tr key={row.id} data-test="rank-row" className="border-b border-white/10 hover:bg-white/5">
                <td className="px-6 py-4 font-semibold text-white">{row.rank}</td>
                <td className="px-6 py-4">{row.username}</td>
                <td className="px-6 py-4">{row.points}</td>
                <td className="px-6 py-4">{row.solved}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
