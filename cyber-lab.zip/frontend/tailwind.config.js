/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        neon: {
          purple: '#b82fff',
          cyan: '#00d4ff',
          pink: '#ff006e',
          blue: '#00bbf9',
          green: '#00ff00',
          yellow: '#ffbe0b',
        },
        cyber: {
          dark: '#0a0e27',
          darker: '#050812',
          bg: '#0f1419',
          card: 'rgba(20, 25, 50, 0.5)',
        },
      },
      backgroundImage: {
        'cyber-gradient': 'linear-gradient(135deg, #0a0e27 0%, #1a1a3e 50%, #0f0f2e 100%)',
        'neon-border': 'linear-gradient(90deg, #b82fff 0%, #00d4ff 50%, #ff006e 100%)',
        'glass-gradient': 'linear-gradient(135deg, rgba(184, 47, 255, 0.1) 0%, rgba(0, 212, 255, 0.1) 100%)',
      },
      boxShadow: {
        neon: '0 0 20px rgba(184, 47, 255, 0.5), 0 0 40px rgba(0, 212, 255, 0.3)',
        'neon-sm': '0 0 10px rgba(184, 47, 255, 0.3)',
        'neon-lg': '0 0 40px rgba(184, 47, 255, 0.6), 0 0 60px rgba(0, 212, 255, 0.4)',
      },
      animation: {
        'pulse-neon': 'pulseNeon 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow': 'glow 3s ease-in-out infinite',
        'float': 'float 3s ease-in-out infinite',
        'scan': 'scan 3s ease-in-out infinite',
      },
      keyframes: {
        pulseNeon: {
          '0%, 100%': { opacity: 1 },
          '50%': { opacity: 0.5 },
        },
        glow: {
          '0%, 100%': {
            boxShadow: '0 0 5px rgba(184, 47, 255, 0.5), 0 0 10px rgba(0, 212, 255, 0.3)',
          },
          '50%': {
            boxShadow: '0 0 20px rgba(184, 47, 255, 0.8), 0 0 30px rgba(0, 212, 255, 0.5)',
          },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        scan: {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100%)' },
        },
      },
      backdropFilter: {
        glass: 'blur(10px)',
      },
    },
  },
  plugins: [
    require('tailwindcss/plugin')(function ({ addUtilities }) {
      addUtilities({
        '.glass': {
          '@apply backdrop-blur-md bg-white bg-opacity-5 border border-white border-opacity-10': {},
        },
        '.glass-dark': {
          '@apply backdrop-blur-md bg-black bg-opacity-20 border border-white border-opacity-10': {},
        },
        '.glass-neon': {
          '@apply backdrop-blur-md bg-gradient-to-br from-purple-500/10 to-cyan-500/10 border border-white border-opacity-10': {},
        },
        '.text-glow': {
          '@apply drop-shadow-[0_0_10px_rgba(184,47,255,0.5)]': {},
        },
        '.text-glow-cyan': {
          '@apply drop-shadow-[0_0_10px_rgba(0,212,255,0.5)]': {},
        },
        '.neon-border': {
          '@apply border border-transparent bg-clip-padding': {},
          backgroundImage:
            'linear-gradient(rgba(20, 25, 50, 0.5), rgba(20, 25, 50, 0.5)), linear-gradient(90deg, #b82fff 0%, #00d4ff 50%, #ff006e 100%)',
          backgroundOrigin: 'border-box',
          backgroundClip: 'padding-box, border-box',
        },
      });
    }),
  ],
};
