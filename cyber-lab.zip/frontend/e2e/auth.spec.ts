import { test, expect } from '@playwright/test';

test.describe('Authentication Flow', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('should display login page', async ({ page }) => {
    await page.goto('/auth/login');
    
    await expect(page).toHaveTitle(/CyberLab/);
    await expect(page.locator('text=Login')).toBeVisible();
    await expect(page.locator('input[name="username"]')).toBeVisible();
    await expect(page.locator('input[name="password"]')).toBeVisible();
  });

  test('should display register page', async ({ page }) => {
    await page.goto('/auth/register');
    
    await expect(page.locator('text=Register')).toBeVisible();
    await expect(page.locator('input[name="username"]')).toBeVisible();
    await expect(page.locator('input[name="email"]')).toBeVisible();
    await expect(page.locator('input[name="password"]')).toBeVisible();
  });

  test('should show error on invalid login', async ({ page }) => {
    await page.goto('/auth/login');
    
    await page.locator('input[name="username"]').fill('invaliduser');
    await page.locator('input[name="password"]').fill('invalidpass');
    await page.locator('button:has-text("Login")').click();
    
    await expect(page.locator('text=Invalid credentials')).toBeVisible();
  });

  test('should show error on weak password during registration', async ({ page }) => {
    await page.goto('/auth/register');
    
    await page.locator('input[name="username"]').fill('newuser');
    await page.locator('input[name="email"]').fill('newuser@example.com');
    await page.locator('input[name="password"]').fill('weak');
    
    await page.locator('button:has-text("Register")').click();
    
    await expect(page.locator('text=at least 12 characters')).toBeVisible();
  });
});

test.describe('Challenge Page', () => {
  test.beforeEach(async ({ page, context }) => {
    // Login first
    // In real scenario, you'd have a login helper
    await page.goto('/auth/login');
    await page.locator('input[name="username"]').fill('admin');
    await page.locator('input[name="password"]').fill('Admin@123456');
    await page.locator('button:has-text("Login")').click();
    
    await page.waitForNavigation();
  });

  test('should display challenges list', async ({ page }) => {
    await page.goto('/challenges');
    
    await expect(page.locator('text=Challenges')).toBeVisible();
    await expect(page.locator('button:has-text("Filter")')).toBeVisible();
  });

  test('should filter challenges by category', async ({ page }) => {
    await page.goto('/challenges');
    
    await page.locator('select').selectOption('Web');
    await page.waitForTimeout(500);
    
    // Verify challenges are shown (should be filtered)
    const challengeCards = await page.locator('[data-test="challenge-card"]').count();
    expect(challengeCards).toBeGreaterThanOrEqual(0);
  });

  test('should open challenge detail', async ({ page }) => {
    await page.goto('/challenges');
    
    // Click first challenge
    await page.locator('[data-test="challenge-card"]').first().click();
    
    await expect(page.locator('text=Difficulty')).toBeVisible();
    await expect(page.locator('button:has-text("Submit Flag")')).toBeVisible();
  });

  test('should show error on invalid flag submission', async ({ page }) => {
    await page.goto('/challenges');
    
    // Click first challenge
    await page.locator('[data-test="challenge-card"]').first().click();
    
    // Submit invalid flag
    await page.locator('input[placeholder="Enter flag"]').fill('CXN{invalid}');
    await page.locator('button:has-text("Submit")').click();
    
    await expect(page.locator('text=Incorrect')).toBeVisible();
  });
});

test.describe('Scoreboard Page', () => {
  test.beforeEach(async ({ page, context }) => {
    // Login first
    await page.goto('/auth/login');
    await page.locator('input[name="username"]').fill('admin');
    await page.locator('input[name="password"]').fill('Admin@123456');
    await page.locator('button:has-text("Login")').click();
    await page.waitForNavigation();
  });

  test('should display scoreboard', async ({ page }) => {
    await page.goto('/scoreboard');
    
    await expect(page.locator('text=Scoreboard')).toBeVisible();
    await expect(page.locator('[data-test="rank-row"]')).toBeDefined();
  });

  test('should display user rank correctly', async ({ page }) => {
    await page.goto('/scoreboard');
    
    // Verify ranking table structure
    const headers = await page.locator('thead th').allTextContents();
    expect(headers).toContain('Rank');
    expect(headers).toContain('Player');
    expect(headers).toContain('Points');
  });
});

test.describe('Admin Pages', () => {
  test.beforeEach(async ({ page }) => {
    // Login as admin
    await page.goto('/auth/login');
    await page.locator('input[name="username"]').fill('admin');
    await page.locator('input[name="password"]').fill('Admin@123456');
    await page.locator('button:has-text("Login")').click();
    await page.waitForNavigation();
  });

  test('should access admin dashboard', async ({ page }) => {
    await page.goto('/admin');
    
    await expect(page.locator('text=Admin Dashboard')).toBeVisible();
    await expect(page.locator('text=Total Users')).toBeVisible();
    await expect(page.locator('text=Total Challenges')).toBeVisible();
  });

  test('should navigate to manage challenges', async ({ page }) => {
    await page.goto('/admin');
    
    await page.locator('a:has-text("Manage Challenges")').click();
    
    await expect(page.locator('text=Challenges')).toBeVisible();
    await expect(page.locator('button:has-text("New Challenge")')).toBeVisible();
  });

  test('should navigate to manage users', async ({ page }) => {
    await page.goto('/admin');
    
    await page.locator('a:has-text("Manage Users")').click();
    
    await expect(page.locator('text=Users')).toBeVisible();
    await expect(page.locator('[data-test="user-row"]')).toBeDefined();
  });

  test('should not access admin as non-admin user', async ({ page }) => {
    // Login as regular user (if available)
    await page.goto('/auth/login');
    await page.locator('input[name="username"]').fill('user');
    await page.locator('input[name="password"]').fill('UserPassword123!');
    await page.locator('button:has-text("Login")').click();
    await page.waitForNavigation();
    
    await page.goto('/admin');
    
    // Should be redirected to home or show access denied
    expect(page.url()).not.toContain('/admin');
  });
});
