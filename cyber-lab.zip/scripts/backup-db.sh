#!/bin/bash
# CyberLab Arena - Database Backup Script
# Location: /var/www/cyberlab/scripts/backup-db.sh
# Usage: sudo bash backup-db.sh [optional-backup-name]

set -e

# Configuration
DB_NAME="cyberlab_db"
DB_USER="cyberlab_user"
BACKUP_DIR="/var/backups/cyberlab"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="${BACKUP_DIR}/cyberlab_backup_${TIMESTAMP}.sql.gz"
RETENTION_DAYS=30

# Create backup directory if not exists
mkdir -p "$BACKUP_DIR"

# Create backup
echo "[$(date)] Starting database backup..."
pg_dump -U "$DB_USER" -d "$DB_NAME" | gzip > "$BACKUP_FILE"

if [ $? -eq 0 ]; then
    echo "[$(date)] Backup completed successfully: $BACKUP_FILE"
    
    # Change permissions
    chmod 600 "$BACKUP_FILE"
    
    # List backups
    echo "[$(date)] Recent backups:"
    ls -lh "$BACKUP_DIR" | tail -5
    
    # Remove old backups (older than RETENTION_DAYS)
    echo "[$(date)] Removing backups older than $RETENTION_DAYS days..."
    find "$BACKUP_DIR" -name "cyberlab_backup_*.sql.gz" -type f -mtime +$RETENTION_DAYS -delete
    
    echo "[$(date)] Backup script completed"
else
    echo "[$(date)] ERROR: Backup failed!"
    exit 1
fi
