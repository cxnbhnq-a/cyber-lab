# CBC++

## Run

```bash
docker compose up -d --build
nc 127.0.0.1 1337
```

## Change flag

Edit Dockerfile:

```bash
CXN{local_fake_flag_change_this}
```

Then rebuild:

```bash
docker compose up -d --build
```

## Suggested public description

I made a tiny C++ number archive. It only adds, swaps, and shows numbers. What could go wrong?

Flag format: `CXN{.*}`

## Author notes, do not publish

The intended bug is unchecked index use in the swap feature. The show feature has bounds check, but swap does not.
The heap layout is designed so that the reserved vector buffer is followed by a heap object containing an exit hook.
A solver can use swap + show to leak a PIE pointer, compute the win() address, then swap a crafted value into the hook and exit.
