#include <iostream>
#include <vector>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <unistd.h>

char name[0x20];
std::vector<unsigned long long> *vec;

struct Hook {
    unsigned long long magic;
    void (*exit_hook)();
};

Hook *hook;

__attribute__((noinline))
void win() {
    std::system("/bin/cat /home/ctf/flag.txt");
}

__attribute__((noinline))
void goodbye() {
    std::cout << "Bye!" << std::endl;
}

void setup_io() {
    std::cout.setf(std::ios::unitbuf);
    std::cin.tie(nullptr);
    alarm(60);
}

void init() {
    setup_io();

    std::memset(name, 0, sizeof(name));
    std::cout << "Your name: ";
    std::cin >> std::setw(sizeof(name)) >> name;

    vec = new std::vector<unsigned long long>();
    vec->reserve(0x100);

    hook = new Hook;
    hook->magic = 0x4342432b2bULL;
    hook->exit_hook = goodbye;
}

void menu() {
    std::cout << "\nHi, " << name << std::endl;
    std::cout << "1. Add new number" << std::endl;
    std::cout << "2. Swap numbers" << std::endl;
    std::cout << "3. Show number" << std::endl;
    std::cout << "4. Exit" << std::endl;
    std::cout << "> ";
}

int main() {
    init();

    int choice = 0;
    int ind1 = 0;
    int ind2 = 0;
    unsigned long long num = 0;

    while (true) {
        menu();

        if (!(std::cin >> choice)) {
            break;
        }

        switch (choice) {
            case 1:
                std::cout << "Num: ";
                std::cin >> std::setbase(0) >> num;
                std::cin >> std::dec;
                vec->push_back(num);
                std::cout << "Done" << std::endl;
                break;

            case 2:
                std::cout << "Index 1: ";
                std::cin >> ind1;
                std::cout << "Index 2: ";
                std::cin >> ind2;

                num = vec->operator[](ind1);
                vec->operator[](ind1) = vec->operator[](ind2);
                vec->operator[](ind2) = num;

                std::cout << "Done" << std::endl;
                break;

            case 3:
                std::cout << "Index: ";
                std::cin >> ind1;
                if (ind1 < 0 || static_cast<size_t>(ind1) >= vec->size()) {
                    std::cout << "Invalid" << std::endl;
                    break;
                }
                std::cout << "Value: " << vec->operator[](ind1) << std::endl;
                break;

            case 4:
                hook->exit_hook();
                return 0;

            default:
                std::cout << "Invalid" << std::endl;
                break;
        }
    }

    return 0;
}
